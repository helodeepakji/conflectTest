<?php
include("settings/conn.php");
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];

$current_url = $protocol . "://" . $host . $uri;
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php?redirect=' . $current_url);
} else {
    $user_id = $_SESSION['userId'];
    $applied_list = $conn->prepare("SELECT * FROM `applied_jobs` WHERE `user_id` = ? ORDER BY `applied_jobs`.`created_at` DESC");
    $applied_list->execute([$user_id]);
    $applied_list = $applied_list->fetchAll(PDO::FETCH_ASSOC);
}

include("settings/include/navbar.php");
?>
<style>
    p,
    h5 {
        margin: 0;
        margin: 5px;
    }

    .header {
        background-color: #c7c7c7;
        padding: 10px 100px;
    }

    a {
        text-decoration: none;
        color: black;
    }

    a:hover {
        text-decoration: none;
        color: black;
    }

    main .boxes {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
    }

    main .boxes .box {
        width: 45%;
        padding: 20px;
        border: 1px solid #e9e9e9;
        border-radius: 10px;
        margin: 20px;
    }

    main .brand {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    main .light-color {
        color: #7a7a7a
    }

    main .box span {
        text-transform: uppercase;
    }

    main .process {
        color: #df8b00;
    }

    main .shortlist,
    main .under_review {
        color: #07da00;
    }

    main .reject {
        color: red;
    }

    main .selected {
        color: #009555;
    }
</style>
<main style="margin-top: 100px">
    <div class="header">
        <h5>Appiled Job</h5>
    </div>
    <div class="container p-4 mt-4">
        <div class="boxes">
            <?php
            foreach ($applied_list as $value) {

                $job = $conn->prepare("SELECT * FROM `jobs` WHERE `id` = ? AND `status` = 1");
                $job->execute([$value["job_id"]]);
                $job = $job->fetch(PDO::FETCH_ASSOC);

                $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ? ");
                $company->execute([$job["company_id"]]);
                $company = $company->fetch(PDO::FETCH_ASSOC);

                echo '<div class="box">
                            <div class="brand">
                                <div class="logo">
                                    <img src="' . $company['image'] . '" width="100px">
                                </div>
                                <div class="company">
                                    <p>' . $job['title'] . '</p>
                                    <p class="light-color">At ' . $company['company'] . '</p>
                                </div>
                            </div>
                            <div class="info">
                                <div class="logo">
                                    <p>Applied Date : <span class="light-color">' . date("d M, Y", strtotime($value['created_at'])) . '</span></p>
                                    <p>Status : <span class="light-color ' . str_replace(" ", "_", $value['status']) . '">' . $value['status'] . '</span></p>
                                </div>
                            </div>
                        </div>';
            }
            ?>
        </div>
    </div>
</main>
<?php include("settings/include/footer.php") ?>