<?php
include("settings/conn.php");
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];

$current_url = $protocol . "://" . $host . $uri;
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php?redirect=' . $current_url);
} else {
    $user_id = $_SESSION['userId'];
    $user = $conn->prepare("SELECT * FROM `users` WHERE `id` = ?");
    $user->execute([$user_id]);
    $user = $user->fetch(PDO::FETCH_ASSOC);
}

include("settings/include/navbar.php");
?>
<style>
    i{
        cursor: pointer;
    }
</style>
<main style="margin-top: 100px;">
    <div class="container ">
        <div class="container py-5">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card mb-4">
                        <div class="card-body text-center">

                            <label for="profile">

                                <img id="profile_image" src="<?php echo $user['profile'] ?>" alt="avatar"
                                    class="rounded-circle img-fluid" style="width: 150px;">
                                <i class="fas fa-edit" style="position: absolute;"></i>
                            </label>
                            <input type="file" name="profile" id="profile" style="display:none" accept="image/*">
                            <h5 class="my-3">
                                <?php echo $user['first_name'] . ' ' . $user['last_name'] ?>
                            </h5>
                        </div>
                    </div>
                    <div class="card col-md-12">
                        <div class="card-body">
                            <h3 class="d-flex" style="font-size: 20px">Change Password</h3>
                            <hr>
                            <form id="changePassword">
                                <div class="row form-row">
                                    <div class="col-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Old Password</label>
                                            <input type="password" class="form-control" name="old_password"  required>
                                            <input type="hidden" class="form-control" name="type" value="changePassword" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row form-row">
                                    <div class="col-12 col-sm-12">
                                        <div class="form-group">
                                            <label>New Password</label>
                                            <input type="password" class="form-control" name="new_password" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row form-row">
                                    <div class="col-12 col-sm-12">
                                        <div class="form-group">
                                            <label>Confirm Password</label>
                                            <input type="password" class="form-control" name="confirm_password" required>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary w-100">Change Password</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="card mb-4 name-card">
                        <div class="card-body">
                            <h1 class="d-flex" style="font-size: 20px">Edit <a data-bs-toggle="modal" href="#edit_user_form" style="margin-left: auto;"><i style="font-weight: 200;" class="fas fa-edit"></i> </a></h1>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Full Name:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['first_name'] . ' ' . $user['last_name'] ?>
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Email:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['email'] ?>
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Phone:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['phone'] ?>
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Rank:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['rank'] ?>
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Qualification:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['qualification'] ?>
                                    </p>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0">Branch:</p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0">
                                        <?php echo $user['branch'] ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="card mb-4 mb-md-0">
                            <div class="card-body">
                                <input type="file" type="file" name="cv" accept=".pdf" id="cvfile" style="display:none">
                                <h1 class="d-flex" style="font-size: 20px">CV/Resume <label style="margin-left: auto;" for="cvfile"><i style="font-weight: 200;" class="fas fa-edit"></i> </label></h1>
                                <div id="pdfContainer">
                                    <object id="pdf_opener" data="<?php echo $user['cv'] ?>" type="application/pdf"
                                        width="100%" height="400">
                                        Your browser does not support embedded PDF files.
                                        You can <a href="<?php echo $user['cv'] ?>">download the PDF</a> instead.
                                    </object>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="edit_user_form" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" name="first_name" value="<?php echo $user['first_name'] ?>" required>
                                <input type="hidden" class="form-control" name="type" value="updatedata" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" name="last_name" value="<?php echo $user['last_name'] ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo $user['email'] ?>" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="number" class="form-control" name="phone" id="edit_phone" value="<?php echo $user['phone'] ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Rank</label>
                                <input type="number" class="form-control" value="<?php echo $user['rank'] ?>"
                                    name="rank" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Qualification</label>
                                <input type="text" class="form-control" value="<?php echo $user['qualification'] ?>"
                                    name="qualification" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include("settings/include/footer.php"); ?>
<script>
    $('#profile').change(() => {
        const fileInput = document.getElementById("profile");
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const formData = new FormData();
            formData.append("profile", file);
            formData.append("type", 'updatedata');
            formData.append("id", <?php echo $user_id ?>);
            $.ajax({
                url: "settings/api/userApi.php",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    $('#profile_image').attr("src", "upload/" + file.name)
                }
            });
        }
    });
    
    $('#cvfile').change(() => {
        const fileInput = document.getElementById("cvfile");
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const formData = new FormData();
            formData.append("cv", file);
            formData.append("type", 'updatedata');
            formData.append("id", <?php echo $user_id ?>);
            $.ajax({
                url: "settings/api/userApi.php",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function (response) {
                    $('#pdf_opener').attr("data", "upload/" + file.name)
                    location.reload();
                }
            });
        }
    });

    $('#editUserForm').submit(function(e){
        e.preventDefault();
        var formData = new FormData(this);
        var phone = $('#edit_phone').val();
        if(phone.length == 10){
            $.ajax({
                url: "settings/api/userApi.php",
                type: "POST",
                data: formData,
                processData: false,
                contentType: false,
                dataType : 'json',
                success: function (response) {
                    notyf.success(response.message);
                    setTimeout(() => {
                        location.reload();
                    }, 1000);
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                    notyf.error(errorMessage);
                }
            });
        }else{
            notyf.error("Phone no must be 10 digits");
        }
    });
    
    $('#changePassword').submit(function(e){
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: "settings/api/userApi.php",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            dataType : 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 1000);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

</script>