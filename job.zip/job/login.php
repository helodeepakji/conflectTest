<?php
include("settings/conn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $check = $conn->prepare('SELECT * FROM `users` WHERE `email` = ?');
    $check->execute([$_POST['email']]);
    $result = $check->fetch(PDO::FETCH_ASSOC);
    if ($result) {
        if (password_verify($_POST['password'], $result['password'])) {
            if($result['user_type'] == 'admin'){
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['userDetails'] = $result;
                $_SESSION['userId'] = $result['id'];
                $_SESSION['userType'] = $result['user_type'];
                setcookie('userId', $result['id'], time() + 3600 * 720);
                if(isset($_GET['redirect']) && $_GET['redirect'] != '') {
                    $targetUrl = $_GET['redirect'];
                    header("location: ".$targetUrl);
                }else{
                    header("location:index.php");
                }
            }else{
                if($result['verfied'] == 1){
                    session_start();
                    $_SESSION['loggedin'] = true;
                    $_SESSION['userDetails'] = $result;
                    $_SESSION['userId'] = $result['id'];
                    $_SESSION['userType'] = $result['user_type'];
                    setcookie('userId', $result['id'], time() + 3600 * 720);
                    if(isset($_GET['redirect']) && $_GET['redirect'] != '') {
                        $targetUrl = $_GET['redirect'];
                        header("location: ".$targetUrl);
                    }else{
                        header("location:index.php");
                    }
                }else{
                    $warning = "Your Registation under verfication.";
                }
            }
        } else {
            $error = "Password is wrong.";
        }
    } else {
        $error = "User not found Check the Email.";
    }
}

include("settings/include/navbar.php");
?>
<style>
    main {
        background-image: url('https://www.joinindiannavy.gov.in/images/home_banner/home_banner_1.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        font-family: Arial, sans-serif;
        width: 100%;
        padding: 50px;
    }

    .login-right,
    .login-left {
        width: 50%;
    }

    .login-right {
        padding: 40px;
        width: 400px;
        background: white;
        text-align: center;
        border-radius: 10px;
    }

    .login-or {
        text-align: center;
    }

    .row {
        justify-content: space-between;
    }
    @media screen and (max-width : 500px) {
        main {
            padding: 10px;
        }
    }
</style>
<main style="margin-top: 100px;">
    <div class="container">
        <div class="row">
            <div class="login-left">
            </div>
            <div class="login-right">
                <?php
                    if(isset($error)) {
                        echo '<div class="alert alert-danger" role="alert">
                                '.$error.'
                            </div>';
                    }
                    if(isset($warning)) {
                        echo '<div class="alert alert-warning" role="alert">
                                '.$warning.'
                            </div>';
                    }
                ?>
                <div class="login-right-wrap">
                    <h3>Login</h3>
                    <p class="account-subtitle">Access to our dashboard</p>
                    <form action="" method="post">
                        <div class="form-group">
                            <input class="form-control" type="email" value="<?php echo $_POST['email'] ?? '' ?>" name="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" name="password" placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary w-100" type="submit">Login</button>
                        </div>
                    </form>
                    <div class="text-center forgotpass"><a href="#forgetPassword" data-bs-toggle="modal">Forgot Password?</a></div>
                    <div class="login-or">
                        <span class="or-line"></span>
                        <span class="span-or">or</span>
                    </div>
                    <div class="text-center dont-have">Don’t have an account? <a href="register.php">Register</a></div>
                </div>
            </div>
        </div>
    </div>
</main>


<!-- Add Modal -->
<div class="modal fade" id="forgetPassword" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Forget Password</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="forgetPasswordForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                                <input type="hidden" class="form-control" name="type" value="forgetPassword" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Send OTP</button>
                </form>
                <form id="otpPasswordForm" style="display:none">
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>OTP</label>
                                <input type="hidden" class="form-control" name="email" id="email" required>
                                <input type="hidden" class="form-control" name="type" value="verifyOtp" required>
                                <input type="number" class="form-control" name="otp" placeholder="Enter OTP" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="setPassword" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Set Password</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="setPasswordForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password" required>
                                <input type="hidden" class="form-control" name="type" value="setPassword" required>
                                <input type="hidden" class="form-control" name="otp" id="payload_otp" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Enter Password Again" required>
                                <input type="hidden" class="form-control" name="email" id="payload_email" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Send OTP</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /ADD Modal -->
<?php include("settings/include/footer.php"); ?>
<script>
    $('#forgetPasswordForm').submit(function(e){
        e.preventDefault();
        Notiflix.Loading.standard();
        var formdata = new FormData(this);
        $.ajax({
            url: 'settings/api/loginApi.php',
            type: 'Post',
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                Notiflix.Loading.remove();
                $('#forgetPasswordForm').css('display','none');
                $('#email').val(response.email);
                $('#otpPasswordForm').css('display','block');
            },
            error: function (xhr, status, error) {
                Notiflix.Loading.remove();
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });
    
    $('#setPasswordForm').submit(function(e){
        e.preventDefault();
        var password = $('#password').val();
        var cpassword = $('#cpassword').val();
        if(password == cpassword){
            Notiflix.Loading.standard();
            var formdata = new FormData(this);
            $.ajax({
                url: 'settings/api/loginApi.php',
                type: 'Post',
                data: formdata,
                cache: false,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    notyf.success(response.message);
                    Notiflix.Loading.remove();
                    $('#setPassword').modal('hide');
                },
                error: function (xhr, status, error) {
                    Notiflix.Loading.remove();
                    var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                    notyf.error(errorMessage);
                }
            });
        }else{
            notyf.error("Password & Confirm Password is not matched");
        }
    });
    
    $('#otpPasswordForm').submit(function(e){
        e.preventDefault();
        Notiflix.Loading.standard();
        var formdata = new FormData(this);
        $.ajax({
            url: 'settings/api/loginApi.php',
            type: 'Post',
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                Notiflix.Loading.remove();
                $('#forgetPassword').modal('hide');
                $('#setPassword').modal('show');
                $('#payload_otp').val(response.otp);
                $('#payload_email').val(response.email);
                $('#otpPasswordForm').css('display','block');
            },
            error: function (xhr, status, error) {
                Notiflix.Loading.remove();
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });
</script>
