<style>
    .flow {
        /* height: 350px; */
        padding: 40px;
        background: #e9e9e8;
    }

    .flow h3 {
        text-align: center;
    }

    .flow .bigbox {
        display: flex;
        padding: 10px;
        justify-content: space-evenly;
    }

    .flow .bigbox .box {
        width: 300px;
        /* height: 200px; */
        margin: 10px;
        border-radius: 10px;
        padding: 10px;
        text-align: center;
    }

    .flow .bigbox .box:hover {
        background-color: white;
    }

    .flow .box h5 {
        font-size: 15px;
        text-align: center
    }

    .flow .icon {
        text-align: center;
        font-size: 32px;
        color: #629fff;
        margin: auto;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        padding: 5px;
        background-color: white;
        margin-bottom: 20px;
    }

    .flow .bigbox .box:hover .icon {
        background-color: #629fff;
        color: white;
    }

    @media screen and (max-width : 700px) {
        .flow .bigbox {
            flex-direction: column;
        }
    }

</style>

<div class="flow">
    <h3>How INPA Work</h3>
    <div class="bigbox">
        <div class="box">
            <div class="icon">
                <i class="fas fa-user-plus"></i>
            </div>
            <h5>Create account</h5>
            <p>Create and manage their profiles with military service and qualifiaction.</p>
        </div>
        <div class="box">
            <div class="icon">
                <i class="fas fa-cloud-upload-alt"></i>
            </div>
            <h5>Upload CV/Resume</h5>
            <p>Search for job listings suited for Navy veterans based on filters like location, industry abd jobs.</p>
        </div>
        <div class="box">
            <div class="icon">
                <i class="fas fa-search-plus"></i>
            </div>
            <h5>Find Suitable Job</h5>
            <p>Recieive job recommendation based on their military background. Post job listing specifically designed
                for Navy veterans.</p>
        </div>
        <div class="box">
            <div class="icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h5>Apply Job</h5>
            <p>Apply for civilian job positions. Recive candidate recommendation based on job requirement.</p>
        </div>
    </div>
</div>