<?php
include("settings/conn.php");
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];

$current_url = $protocol . "://" . $host . $uri;
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php?redirect=' . $current_url);
} else {
    $user_id = $_SESSION['userId'];
    $user = $conn->prepare("SELECT * FROM `users` WHERE `id` = ?");
    $user->execute([$user_id]);
    $user = $user->fetch(PDO::FETCH_ASSOC);
}

if (isset($_GET["id"])) {
    $job = $conn->prepare("SELECT * FROM `jobs` WHERE `id` = ? AND `status` = 1");
    $job->execute([$_GET["id"]]);
    $job = $job->fetch(PDO::FETCH_ASSOC);

    $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ? ");
    $company->execute([$job["company_id"]]);
    $company = $company->fetch(PDO::FETCH_ASSOC);
}




include("settings/include/navbar.php");
?>
<style>
    h5 {
        margin: 0;
    }

    .header {
        background-color: #c7c7c7;
        padding: 10px 100px;
    }

    a {
        text-decoration: none;
        color: black;
    }

    a:hover {
        text-decoration: none;
        color: black;
    }

    main .job-title-info,
    main .job-details {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    span.text-uppercase {
        background: #04cb04;
        color: white;
        padding: 5px 10px;
        font-size: 10px;
    }

    main .job-description .job-info {
        width: 50%;
        padding: 10px 0;
    }

    main .job-description .other-details {
        width: 40%;
    }

    main .job-description {
        display: flex;
        justify-content: space-between;
    }

    main .box {
        text-align: center;
        display: flex;
        align-items: center;
        border-radius: 10px;
        border: 1px solid #dadbdb;
        margin: 10px 0;
    }

    main .boxes i {
        color: #1190d3;
        font-size: 30px;
        padding: 15px;
    }

    .first-box {
        border-right: 1px solid #dadbdb;
        margin: 10px;
    }

    .first-box,
    .second-box {
        width: 100%;
    }



    main .job_list {
        margin: 50px 0;
    }

    main .data {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    main p {
        margin: 0;
    }

    main p.company_name {
        font-weight: 600;
    }

    main p.location_details {
        color: #8b8b8b;
    }

    main .card-body {
        background-image: linear-gradient(248deg, #cdeaff, #ff00000d);
    }

    main .share-box {
        display: block;
        text-align: left;
        padding: 10px;
    }

    .social-media-share {
        display: flex;
        justify-content: space-around;
    }

    .social-media-share i {
        color: #007bff;
        margin: 0 10px;
        font-size: 20px;
    }

    @media screen and (max-width : 800px) {
        main .job-description {
            flex-direction: column;
        }

        main .job-description .job-info {
            width: 100%;
        }

        main .job-description .other-details {
            width: 100%;
        }

        main .job-title-info,
        main .job-details {
            flex-direction: column;
        }
    }
</style>
<main style="margin-top: 100px;">
    <div class="header">
        <h5>Job Details</h5>
    </div>
    <div class="container p-4 mt-4">
        <div class="job-details">
            <div class="job-title-info" style="width:300px">
                <div class="logo">
                    <img src="<?php echo $company['image'] ?>" width="100px" alt="">
                </div>
                <div class="details">
                    <h5 class="title">
                        <?php echo $job['title'] ?>
                    </h5>
                    <div class="company_name p-2" style="color: #707070;">
                        At
                        <?php echo $company['company'] ?> <span class="text-uppercase <?php echo $job['job_type'] ?>">
                            <?php echo $job['job_type'] ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="apply-btn">
                <?php
                $applied_list = $conn->prepare("SELECT * FROM `applied_jobs` WHERE `user_id` = ? AND `job_id` = ? AND `status` != 'reject'");
                $applied_list->execute([$user_id, $_GET["id"]]);
                $applied_list = $applied_list->fetch(PDO::FETCH_ASSOC);
                if (!$applied_list) {
                    echo '<button data-bs-toggle="modal" href="#apply_job" class="btn btn-primary mt-2"
                        style="background:#007bff;padding: 5px 50px;">Apply Now <i
                            class="fa-solid fa-arrow-right ml-2 mr-2"></i></button>';
                } else {
                    echo '<a href="applied-job.php" class="btn btn-danger mt-2"
                        style="padding: 5px 50px;">Already Applied <i
                            class="fa-solid fa-eye ml-2 mr-2"></i></a>';
                }
                ?>

            </div>
        </div>
        <div class="job-description m-2">
            <div class="job-info">
                <div>
                    <h6>Job Description</h6>
                    <p>
                        <?php echo $job['description'] ?>
                    </p>
                </div>
                <div class="mt-4">
                    <h6>Company Description</h6>
                    <p>
                        <?php echo $company['description'] ?>
                    </p>
                </div>
            </div>
            <div class="other-details">
                <div class="box boxes">
                    <div class="first-box">
                        <i class="fa-regular fa-map"></i>
                        <p style="margin: 0;">Job Location </p>
                        <span style="color: #8e8a82;">
                            <?php echo $job['location'] ?>
                        </span>

                    </div>
                    <div class="second-box">
                        <i class="fa-regular fa-calendar"></i>
                        <p style="margin: 0;">Posted </p>
                        <span style="color: #8e8a82;">
                            <?php echo date("d M, Y h:i A", strtotime($job['created_at'])); ?>
                        </span>
                    </div>
                </div>

                <div class="box share-box">
                    <p>Share this job : </p>
                    <hr>
                    <div class="social-media-share">
                        <button type="button" class="btn btn-outline-primary btn-sm" id="copyLinkButton">Copy Link <i
                                class="fa-regular fa-clipboard"></i></button>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url; ?>"
                            target="_blank">
                            <i class="fa-brands fa-facebook-f"></i>
                        </a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo $current_url; ?>&text=Check out this job posting: UI Designer"
                            target="_blank">
                            <i class="fa-brands fa-twitter"></i>
                        </a>
                        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $current_url; ?>&title=UI%20Designer%20Job%20Posting"
                            target="_blank">
                            <i class="fa-brands fa-linkedin-in"></i>
                        </a>
                    </div>

                </div>
            </div>
        </div>
        <div class="job_list">
            <h3 style="padding: 20px 0;">Related Jobs</h3>
            <div class="row">
                <?php
                $joblist = $conn->prepare("SELECT * FROM `jobs` WHERE `title` LIKE ? AND `status` = 1 AND `id` != ?");
                $joblist->execute(['%' . $job['title'] . '%', $_GET['id']]);
                $joblist = $joblist->fetchAll(PDO::FETCH_ASSOC);

                if (count($joblist) == 0) {
                    echo '<div class="col-12 col-md-6 col-lg-4 d-flex mb-2">
                            <div class="card flex-fill">
                                <div class="card-body">
                                <h5 style="padding: 20px 0;">No Jobs</h5>
                        </div></div></div>';
                }

                foreach ($joblist as $value) {
                    $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ?");
                    $company->execute([$value['company_id']]);
                    $company = $company->fetch(PDO::FETCH_ASSOC);
                    ?>
                    <div class="col-12 col-md-6 col-lg-4 d-flex mb-2">
                        <div class="card flex-fill">
                            <div class="card-body">
                                <a href="job-details.php?id=<?php echo $value['id'] ?>">
                                    <h5>
                                        <?php echo $value['title'] ?>
                                    </h5>
                                </a>
                                <div class="data">
                                    <img src="<?php echo $company['image'] ?>" width="50px" alt="">
                                    <div class="location">
                                        <p class="company_name">
                                            <?php echo $company['company'] ?>
                                        </p>
                                        <p class="location_details"><i class="fas fa-map-marker-alt"></i>
                                            <?php echo $value['location'] ?>
                                        </p>
                                        <p class="location_details">Post Date :
                                            <?php echo date("d M, Y", strtotime($value['created_at'])); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</main>

<div class="modal fade" id="apply_job" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Apply Job</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="applyJobs">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" name="first_name" id="first_name"
                                    value="<?php echo $user['first_name'] ?>" required readonly>
                                <input type="hidden" class="form-control" name="type" value="applyJob" required>
                                <input type="hidden" name="job_id" value="<?php echo $job['id'] ?>">
                                <input type="hidden" name="company_id" value="<?php echo $job['company_id'] ?>">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" value="<?php echo $user['last_name'] ?>"
                                    name="last_name" required readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" value="<?php echo $user['email'] ?>"
                                    name="email" required readonly>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="number" class="form-control" value="<?php echo $user['phone'] ?>"
                                    name="phone" required readonly>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Rank</label>
                                <input type="number" class="form-control" value="<?php echo $user['rank'] ?>"
                                    name="rank" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Qualification</label>
                                <input type="text" class="form-control" value="<?php echo $user['qualification'] ?>"
                                    name="qualification" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>CV/Resume</label>
                                <input type="file" class="form-control" name="cv" id="cvfiles" accept=".pdf"
                                    onchange="displaySelectedPDF()">
                            </div>
                        </div>
                    </div>
                    <div id="pdfContainer">
                        <object id="pdf_opener" data="<?php echo $user['cv'] ?>" type="application/pdf" width="100%"
                            height="400">
                            Your browser does not support embedded PDF files.
                            You can <a href="<?php echo $user['cv'] ?>">download the PDF</a> instead.
                        </object>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Apply</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="delete_modal" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-content p-2">
                    <h4 class="modal-title">Congratulations</h4>
                    <p class="mb-4">You Application is Successfull Uploaded</p>
                    <button type="button" id="close_delete_btn" class="btn btn-danger"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("settings/include/footer.php"); ?>
<script>
    const copyLinkButton = document.getElementById("copyLinkButton");

    // Add a click event listener to the button
    copyLinkButton.addEventListener("click", function () {
        // Specify the link to copy
        const linkToCopy = window.location.href;

        // Create a temporary input element
        const tempInput = document.createElement("input");
        tempInput.value = linkToCopy;
        document.body.appendChild(tempInput);

        // Select and copy the link
        tempInput.select();
        document.execCommand("copy");

        // Remove the temporary input element
        document.body.removeChild(tempInput);

        // Provide feedback to the user
        notyf.success("Link copied to clipboard.");
    });

    function displaySelectedPDF() {
        var fileInput = document.getElementById('cvfiles');
        var pdfContainer = document.getElementById('pdfContainer');

        if (fileInput.files.length > 0) {
            var selectedFile = fileInput.files[0];

            if (selectedFile.type === 'application/pdf') {
                var reader = new FileReader();

                reader.onload = function (e) {
                    pdfContainer.innerHTML = '<embed src="' + e.target.result + '" type="application/pdf" width="100%" height="400px" />';
                };

                reader.readAsDataURL(selectedFile);
            } else {
                pdfContainer.innerHTML = 'Selected file is not a PDF.';
            }
        } else {
            pdfContainer.innerHTML = 'No file selected.';
        }
    }

    $('#applyJobs').submit(function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: 'settings/api/applyjobApi.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                $('#apply_job').modal("hide");
                $('#delete_modal').modal("show");
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });
</script>