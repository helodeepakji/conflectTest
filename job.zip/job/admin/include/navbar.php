<?php

session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true || $_SESSION['userType'] != 'admin') {
    header("location: ../index.php");
} else {
    $user_id = $_SESSION['userId'];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap-grid.min.css"
        integrity="sha512-Aa+z1qgIG+Hv4H2W3EMl3btnnwTQRA47ZiSecYSkWavHUkBF2aPOIIvlvjLCsjapW1IfsGrEO3FU693ReouVTA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
</head>


<style>
    /* Sidebar */
    main {
        margin: 100px 0 0 250px;
    }

    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        padding: 58px 0 0;
        box-shadow: 0 2px 5px 0 rgb(0 0 0 / 5%), 0 2px 10px 0 rgb(0 0 0 / 5%);
        width: 240px;
        z-index: 600;
    }


    .sidebar .active {
        border-radius: 5px;
        box-shadow: 0 2px 5px 0 rgb(0 0 0 / 16%), 0 2px 10px 0 rgb(0 0 0 / 12%);
        margin: 5px 0 !important;
    }

    .sidebar-sticky {
        /* position: relative; */
        top: 0;
        height: calc(100vh - 48px);
        padding-top: 0.5rem;
        overflow-x: hidden;
        overflow-y: auto;
        /* Scrollable contents if viewport is shorter than content. */
    }


    .sec h1 {
        position: fixed;
        top: 50px;
        background-color: #FFD700;
        padding: 0 10px;

    }

    .sidebar1 {
        position: absolute;
        top: 0;
        padding: 58px 0 0;
        box-shadow: 0 2px 5px 0 rgb(0 0 0 / 2%), 0 2px 1px 0 rgb(0 0 0 / 2%);
        width: 402px;

        z-index: 600;
    }

    .project_id p {
        width: 370px;
    }

    .news {

        margin-left: 30px;
    }

    .news h1 {
        width: 545px;
        text-align: center;

    }

    .news {
        box-shadow: 0 2px 5px 0 rgb(0 0 0 / 5%), 0 2px 10px 0 rgb(0 0 0 / 5%);
        /* width: 100%; */
    }

    .toast {
        margin-top: 40px;
        border: 1px solid black;
        width: 550px
    }

    .news .bor {
        border: solid black;
    }


    .margin-5 {
        margin: 5px;
    }

    .margin-left-26 {
        margin-left: 26px;
    }

    .home {
        width: 100%;
        height: 100vh;
        margin-top: 10px;
    }

    .home .logo img {
        width: 60px;
        height: auto;

    }

    .row {
        --bs-gutter-x: 0rem;
    }

    .Descrption input {
        background-color: #f0f8ff;
    }

    .indipended {
        /* margin: 0px;
    padding: 0px; */
        display: block;
        display: flex;
        align-items: center;

        /* background-color: blue; */
        color: #fff;
        font-size: 12px;
        border-radius: 5px;
    }

    .development-text {
        font-weight: 900px;

        background-color: blue;
        border-radius: 3px;
    }

    .right-buttom {
        margin-left: 60px;
    }

    #vw {
        font-size: 11px;
    }

    .imo {
        background-color: #00a3bf;
        border-radius: 8px;
        /* color: yellow; */
    }

    .imo-r {
        background-color: red;
        border-radius: 8px;
    }

    #box1 {

        display: block;
        position: relative;

    }

    .bg-btn {
        background-color: rgb(232, 232, 232);
    }

    .right {
        background-color: #F4F6F6;
    }

    .icon {
        margin-left: -3px;
    }

    .Time-traking {
        margin-top: 12px;
    }

    @media(max-width:1280) {
        .dates input {
            margin-left: 10px;
        }
    }

    @media(max-width:1366) {
        .dates input {
            margin-left: 20px !important;
        }
    }

    .dates input {
        margin-left: 3px;
    }

    .sidebar a:hover {
        background-color: #0d6efd;
        color: white;
        border-radius: 8px;
    }

    .sidebar a:active {
        background-color: #0d6efd;
        color: white;
        border-radius: 8px;
    }

    .Agile {
        margin-top: 6px;
    }

    .dropdown-menu{
        border: none;
    }
</style>
</head>

<body>
    <header>
        <!-- Sidebar -->
        <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white d-flex">
            <div>
                <div class="position-sticky">
                    <div class="list-group list-group-flush mx-3 mt-4">
                        <a href="company.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "company" ? "active" : "" ?>"
                            aria-current="true">
                            <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Company</span>
                        </a>
                        <a href="jobs.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "jobs" ? "active" : "" ?>"><i
                                class="fas fa-building fa-fw me-3"></i><span>Jobs</span></a>
                        <a href="user.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "users" ? "active" : "" ?>"><i
                                class="fas fa-user fa-fw me-3"></i><span>Users</span></a>
                        <a href="notification.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "notification" ? "active" : "" ?>"><i
                                class="fas fa-message fa-fw me-3"></i><span>Notification</span></a>
                        <a href="applied-jobs.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "applied-jobs" ? "active" : "" ?>"><i
                                class="fas fa-vector-square fa-fw me-3"></i><span>Applied Jobs</span></a>
                        <a href="contact.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "contact" ? "active" : "" ?>"><i
                                class="fas fa-phone fa-fw me-3"></i><span>Contact</span></a>
                        <a href="partner.php"
                            class="list-group-item list-group-item-action py-2 ripple <?php echo $current_page == "partner" ? "active" : "" ?>"><i
                                class="fas fa-building fa-fw me-3"></i><span>Partner Companies</span></a>
                        <div class="dropdown">
                            <a href="#" class="list-group-item list-group-item-action py-2 ripple dropdown-toggle"
                                role="button" id="settingsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-cog fa-fw me-3"></i><span>Settings</span>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="settingsDropdown">
                                <li><a class="dropdown-item" href="../profile.php">Profile</a></li>
                                <!-- <li><a class="dropdown-item" href="#">Preferences</a></li> -->
                                <li><a class="dropdown-item" href="../logout.php">Log Out</a></li>
                            </ul>
                        </div>
                    </div>

                </div>


        </nav>

        <!-- Sidebar -->

        <!-- Navbar -->
        <nav id="main-navbar" class="navbar navbar-expand-lg navbar-light bg-white fixed-top"
            style="border-bottom: 1px solid #e5e5e5;">
            <!-- Container wrapper -->
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarMenu"
                    aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Brand -->
                <a class="navbar-brand" href="#"
                    style="width: 210px; display: flex;justify-items: center;align-items: center;justify-content: space-evenly;">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Indian_Navy_Crest.png" width="35px"
                        alt="">
                    <h5>Admin Page</h5>
                </a>
            </div>
            <!-- Container wrapper -->
        </nav>
    </header>