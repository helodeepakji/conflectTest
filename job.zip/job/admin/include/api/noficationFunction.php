<?php

    function addNotification($conn , $nofication , $file){
        $notification = $conn->prepare('INSERT INTO `notification`(`notification`, `file`) VALUES (? , ?)');
        $result = $notification->execute([$nofication , $file]);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
    
    function deletetNotification($conn , $nofication_id){
        $notification = $conn->prepare('DELETE FROM `notification` WHERE `id` = ?');
        $result = $notification->execute([$nofication_id]);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }