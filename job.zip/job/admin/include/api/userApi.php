<?php

    include("../../../settings/conn.php");
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'verfiedUser')) {
        if ($_POST['id'] != ''){
            $update = $conn->prepare('UPDATE  `users` SET `verfied` = 1 WHERE `id` = ?');
            $result = $update->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Verfied User.", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
    
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'unVerfiedUser')) {
        if ($_POST['id'] != ''){
            $update = $conn->prepare('UPDATE  `users` SET `verfied` = 0 WHERE `id` = ?');
            $result = $update->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull unVerfied User.", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }

?>