<?php

    include("../../../settings/conn.php");
    session_start();
    $user_id = $_SESSION['userId'];
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'changeStatus')) {
        if ($_POST['applied_id'] != '' && $_POST['status'] != ''){
            $update = $conn->prepare('UPDATE  `applied_jobs` SET `status` = ? WHERE `id` = ?');
            $result = $update->execute([$_POST['status'] ,$_POST['applied_id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Uploaded Status." ,"changeStatus" =>  $_POST['status'], "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }else{
            http_response_code(400);
            echo json_encode(["message" => "Fill All Required Fields.", "status" => 400]);
        }
    }
?>