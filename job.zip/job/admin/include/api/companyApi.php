<?php

include("../../../settings/conn.php");
if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'addCompany')) {
    if ($_POST['company_name'] != '' && $_POST['company_details'] != '' && $_FILES['company_logo']['name']) {
        $company_logo = basename($_FILES['company_logo']['name']);
        $uploadPath = '../../../upload/' . $company_logo;
        move_uploaded_file($_FILES['company_logo']['tmp_name'], $uploadPath);
        $company_logo_link = $socket . 'upload/' . $company_logo;

        $company = $conn->prepare('INSERT INTO `company`( `company`, `image`, `description`) VALUES ( ? , ? , ? )');
        $result0 = $company->execute([$_POST['company_name'], $company_logo_link, $_POST['company_details']]);
        if ($result0) {
            http_response_code(200);
            echo json_encode(["message" => "Company Uploaded Successfull.", "status" => 200]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Something went wrong.", "status" => 500]);
        }
    }else {
        http_response_code(400);
        echo json_encode(["message" => "Fill All Required Fields.", "status" => 400]);
    }
}

if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'updateCompany')) {
    if ($_POST['company_name'] != '' && $_POST['company_details'] != '' && $_POST['company_id'] != '') {

        if($_FILES['company_logo']['name']){
            $company_logo = basename($_FILES['company_logo']['name']);
            $uploadPath = '../../../upload/' . $company_logo;
            move_uploaded_file($_FILES['company_logo']['tmp_name'], $uploadPath);
            $company_logo_link = $socket . 'upload/' . $company_logo;
            $company = $conn->prepare('UPDATE `company` SET `company` = ?, `description` = ?)');
            $result = $company->execute([$company_logo_link, $_POST['company_id']]);
        }

        $company = $conn->prepare('UPDATE `company` SET `company` = ?, `description` = ? WHERE `id` = ?');
        $result = $company->execute([$_POST['company_name'], $_POST['company_details'], $_POST['company_id']]);
        if ($result) {
            http_response_code(200);
            echo json_encode(["message" => "Company Uploaded Successfull.", "status" => 200]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Something went wrong.", "status" => 500]);
        }
    }else {
        http_response_code(400);
        echo json_encode(["message" => "Fill All Required Fields.", "status" => 400]);
    }
}

if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'deleteCompany')) {
    if ($_POST['company_id'] != '') {
        $company = $conn->prepare('DELETE FROM `company` WHERE `id` = ?');
        $result = $company->execute([$_POST['company_id']]);
        if ($result) {
            http_response_code(200);
            echo json_encode(["message" => "Company Delete Successfull.", "status" => 200]);
        } else {
            http_response_code(500);
            echo json_encode(["message" => "Something went wrong.", "status" => 500]);
        }
    }else {
        http_response_code(400);
        echo json_encode(["message" => "Fill All Required Fields.", "status" => 400]);
    }
}


?>