<?php

    include("../../../settings/conn.php");
    include("noficationFunction.php");
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'addNotification')) {
        if ($_POST['notification'] != ''){
            if($_FILES['file']['name'] != ''){
                $company_logo = basename($_FILES['file']['name']);
                $uploadPath = '../../../upload/' . $company_logo;
                move_uploaded_file($_FILES['file']['tmp_name'], $uploadPath);
                $notification_link = $socket . 'upload/' . $company_logo;
            }else{
                $notification_link = '';
            }

            if (addNotification($conn , $_POST['notification'] , $notification_link)) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Add ." ,"changeStatus" =>  "Unread", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
    
    
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'hideNotication')) {
        if ($_POST['id'] != ''){
            
            $notification = $conn->prepare('UPDATE `notification` SET `status` = 0 WHERE `id` = ?');
            $result = $notification->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Uploaded Status." ,"changeStatus" =>  "Unread", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
    
    
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'showNotication')) {
        if ($_POST['id'] != ''){
            
            $notification = $conn->prepare('UPDATE `notification` SET `status` = 1 WHERE `id` = ?');
            $result = $notification->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Uploaded Status." ,"changeStatus" =>  "Unread", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
    
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'deleteNotification')) {
        if ($_POST['id'] != ''){
        
            if (deletetNotification($conn , $_POST['id'])) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Dekete Notification." ,"changeStatus" =>  "Unread", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }