<?php

    include("../../../settings/conn.php");
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'unReadContact')) {
        if ($_POST['id'] != ''){
            $update = $conn->prepare('UPDATE  `contact` SET `status` = 0 WHERE `id` = ?');
            $result = $update->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Uploaded Status." ,"changeStatus" =>  "Unread", "status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
    
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'readContact')) {
        if ($_POST['id'] != ''){
            $update = $conn->prepare('UPDATE  `contact` SET `status` = 1 WHERE `id` = ?');
            $result = $update->execute([$_POST['id']]);
            if ($result) {
                http_response_code(200);
                echo json_encode(["message" => "Successfull Uploaded Status." , "changeStatus" =>  "Read","status" => 200]);
            } else {
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong.", "status" => 500]);
            }
        }
    }
?>