<?php
$current_page = "applied-jobs";
include("../settings/conn.php");
$applied_jobs = $conn->prepare("SELECT * FROM `applied_jobs`");
$applied_jobs->execute();
$applied_jobs = $applied_jobs->fetchAll(PDO::FETCH_ASSOC);
include("include/navbar.php");
?>
<main style="margin-top: 100px;">
    <div class="container pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between" style="padding: 0 0 40px 0; font-size: 25px;">
                <p class="fw-bold">Applied Jobs</p>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        First Name
                    </th>
                    <th>
                        Last Name
                    </th>
                    <th>
                        Job Title
                    </th>
                    <th>
                        Company Name
                    </th>
                    <th>
                        Applied Date
                    </th>
                     <th>
                        CV/Resume
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 0;
                    foreach ($applied_jobs as $key => $value) {
                        $user = $conn->prepare("SELECT * FROM `users` WHERE `id` = ?");
                        $user->execute([$value["user_id"]]);
                        $user = $user->fetch(PDO::FETCH_ASSOC);
                        
                        $job = $conn->prepare("SELECT * FROM `jobs` WHERE `id` = ?");
                        $job->execute([$value["job_id"]]);
                        $job = $job->fetch(PDO::FETCH_ASSOC);
                        
                        $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ?");
                        $company->execute([$value["company_id"]]);
                        $company = $company->fetch(PDO::FETCH_ASSOC);

                        $status = $value['status'];

                        echo '<tr>
                                <td>'.++$i.'</td>
                                <td>'.$user['first_name'].'</td>
                                <td>'.$user['last_name'].'</td>
                                <td>'.$job['title'].'</td>
                                <td>'.$company['company'].'</td>
                                <td>'.date("d M, Y h:i A", strtotime($value['created_at'])).'</td>
                                <td><a href="'.$user['cv'].'" target="_blank">Open CV/Resume</a></td>
                                <td class="text-uppercase" id="change_status_'.$value['id'].'" >'.$value['status'].'</td>
                                <td>
                                    <select class="form-control" id="status_'.$value['id'].'" onchange="changeStatus('.$value['id'].')">
                                        <option class="process" '.($status == 'process' ? 'selected' : '').'> Process </option>
                                        <option class="reject" '.($status == 'reject' ? 'selected' : '').'> Reject </option>
                                        <option class="shortlist" '.($status == 'shortlist' ? 'selected' : '').'> Shortlist </option>
                                        <option class="under review" '.($status == 'under review' ? 'selected' : '').'> Under Review </option>
                                        <option class="selected" '.($status == 'selected' ? 'selected' : '').'> Selected </option>
                                    </select>
                                </td>
                            </tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include('include/footer.php') ?>
<script>
    function changeStatus(id){
        var status = $('#status_'+id).val();
        $.ajax({
            url: 'include/api/applyJobApi.php',
            type: 'POST',
            data: {
                type : 'changeStatus',
                applied_id : id,
                status : status
            },
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                $('#change_status_'+id).text(response.changeStatus);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    }
</script>