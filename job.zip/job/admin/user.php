<?php
$current_page = "users";
include("../settings/conn.php");
$users = $conn->prepare("SELECT * FROM `users` WHERE `user_type` != 'admin'");
$users->execute();
$users = $users->fetchAll(PDO::FETCH_ASSOC);
include("include/navbar.php");
?>
<main style="margin-top: 100px;">
    <div class="pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between" style="padding: 0 0 40px 0; font-size: 25px;">
                <p class="fw-bold">User List</p>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Profile
                    </th>
                    <th>
                        First Name
                    </th>
                    <th>
                        Last Name
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Phone
                    </th>
                    <th>
                        Rank
                    </th>
                    <th>
                        Qualification
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Branch
                    </th>
                    <th>
                        CV/Resume
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 0;
                    foreach ($users as $key => $value) {
                        if($value['verfied'] == 1){
                            $button = '<button data-bs-toggle="modal" class="btn btn-outline-danger" onclick="unverifiedUser('.$value['id'].')">UnVerify</button>';
                        }else{
                            $button = '<button data-bs-toggle="modal" class="btn btn-outline-success" onclick="verifiedUser('.$value['id'].')">Verify</button>';
                        }

                        echo '<tr>
                                <td>'.++$i.'</td>
                                <td><img src="'.$value['profile'].'" width="50px"></td>
                                <td>'.$value['first_name'].'</td>
                                <td>'.$value['last_name'].'</td>
                                <td>'.$value['email'].'</td>
                                <td>'.$value['phone'].'</td>
                                <td>'.$value['rank'].'</td>
                                <td>'.$value['qualification'].'</td>
                                <td class="'.($value['verfied'] == 1 ? 'text-success' : 'text-danger').'">'.($value['verfied'] == 1 ? 'verified' : 'unverified').'</td>
                                <td>'.$value['branch'].'</td>
                                <td><a href="'.$value['cv'].'" target="_blank">CV/Resume</a></td>
                                <td>'.$button.'</td>
                            </tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php include('include/footer.php') ?>
<script>
    function verifiedUser(id){
        $.ajax({
            url: 'include/api/userApi.php',
            type: 'POST',
            data: {
                type : 'verfiedUser',
                id : id
            },
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    }
    
    function unverifiedUser(id){
        $.ajax({
            url: 'include/api/userApi.php',
            type: 'POST',
            data: {
                type : 'unVerfiedUser',
                id : id
            },
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    }
</script>