<?php
$current_page = "company";
include("../settings/conn.php");
$company = $conn->prepare("SELECT * FROM `company`");
$company->execute();
$company = $company->fetchAll(PDO::FETCH_ASSOC);
include("include/navbar.php");
?>
<main style="margin-top: 100px;">
    <div class="container pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between" style="padding: 0 0 40px 0; font-size: 25px;align-items: center;">
                <p class="fw-bold">Company List</p>
                <a href="#Add_Specialities_details" data-bs-toggle="modal" class="btn btn-primary">Add</a>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Name
                    </th>
                    <th>
                        Description
                    </th>
                    <th>
                        Logo
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 0;
                    foreach ($company as $key => $value) {
                        $data = base64_encode(json_encode($value));
                        echo '<tr id="tr'.$value['id'].'">
                                <td>'.++$i.'</td>
                                <td>'.$value['company'].'</td>
                                <td>'.substr($value['description'], 0, 70).'....</td>
                                <td><img src="'.$value['image'].'" width="50px"></td>
                                <td>
                                <button data-bs-toggle="modal" class="btn btn-sm bg-success-light" onclick="editCompany(\''.$data.'\')">Edit</button>
                                <a href="#delete_modal"  data-bs-toggle="modal" class="btn btn-sm bg-danger-light" onclick="deleteCompany('.$value['id'].')">Delete</a></td>
                            </tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</main>



<!-- Add Modal -->
<div class="modal fade" id="Add_Specialities_details" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Company</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="addCompanyForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company Name</label>
                                <input type="text" class="form-control" name="company_name" required>
                                <input type="hidden" class="form-control" name="type" value="addCompany" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" name="company_logo">
                            </div>
                        </div>

                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>Company Details</label>
                                <input type="text" class="form-control" name="company_details" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /ADD Modal -->

<!-- Edit Details Modal -->
<div class="modal fade" id="edit_specialities_details" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Company</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="updateCompany">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company Name</label>
                                <input type="text" class="form-control" value="" id="edit_company_name"
                                    name="company_name">
                                <input type="hidden" class="form-control" value="" id="edit_company_id"
                                    name="company_id">
                                <input type="hidden" class="form-control" value="updateCompany"  name="type">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" name="company_logo">
                            </div>
                        </div>

                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>Company Details</label>
                                <textarea class="form-control" name="company_details"
                                    id="edit_company_details"></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save Changes</button>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Edit Details Modal -->

<!-- Delete Modal -->
<div class="modal fade" id="delete_modal" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-content p-2">
                    <h4 class="modal-title">Delete</h4>
                    <p class="mb-4">Are you sure want to delete?</p>
                    <button type="button" id="delete_btn" delete-data="0" class="btn btn-primary">Delete </button>
                    <button type="button" id="close_delete_btn" class="btn btn-danger"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php') ?>
<script>
    function editCompany(data){
        data = JSON.parse(atob(data));
        console.log(data);
        $('#edit_specialities_details').modal('show');
        $('#edit_company_name').val(data.company);
        $('#edit_company_details').val(data.description);
        $('#edit_company_id').val(data.id);
    }

    $('#addCompanyForm').submit(function(e){
        e.preventDefault();
        var formdata = new FormData(this);
        $.ajax({
            url: 'include/api/companyApi.php',
            type: 'Post',
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                $('#Add_Specialities_details').modal('hide');
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });
    
    $('#updateCompany').submit(function(e){
        e.preventDefault();
        var formdata = new FormData(this);
        $.ajax({
            url: 'include/api/companyApi.php',
            type: 'Post',
            data: formdata,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                $('#edit_specialities_details').modal('hide');
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

    function deleteCompany(id){
        $("#delete_btn").attr("delete-data", id);
    }


    $("#delete_btn").click(function() {
        var id = $(this).attr("delete-data");
        console.log(id);
        $.ajax({
            url: 'include/api/companyApi.php',
            type: 'POST',
            data: {
                type : 'deleteCompany',
                company_id:id
            },
            dataType: 'json',
            success: function (response) {
                $('#close_delete_btn').click();
                $("#tr"+id).remove();
                notyf.success(response.message);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

</script>