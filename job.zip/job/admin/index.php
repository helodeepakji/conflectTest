<?php 
    include("include/navbar.php");
?>
<?php include('include/footer.php') ?>