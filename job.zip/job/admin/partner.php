<?php
    $current_page = "partner";
    include("../settings/conn.php");
    $partners = $conn->prepare("SELECT * FROM `partners`");
    $partners->execute();
    $partners = $partners->fetchAll(PDO::FETCH_ASSOC);
    include("include/navbar.php");
?>

<main style="margin-top: 100px;">
    <div class="container pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between"
                style="padding: 0 0 40px 0; font-size: 25px;align-items: center;">
                <p class="fw-bold">Partner Companies</p>
                <a href="#Add_Specialities_details" data-bs-toggle="modal" class="btn btn-primary">Add</a>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Url
                    </th>
                    <th>
                        Image
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($partners as $key => $value) {
                    echo '<tr id="tr'.$value['id'].'">
                                <td>' . ++$i . '</td>
                                <td>' . $value['url'] . '</td>
                                <td><img src="../' . $value['image'] . '" width="80px"></td>
                                <td style="display: flex;">
                                    <a href="#delete_modal" data-bs-toggle="modal"  class="btn btn-sm bg-danger" onclick="deleteJob('.$value['id'].')">Delete</a>
                                </td>
                            </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<div class="modal fade" id="delete_modal" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-content p-2">
                    <h4 class="modal-title">Delete</h4>
                    <p class="mb-4">Are you sure want to delete?</p>
                    <button type="button" id="delete_btn" delete-data="0" class="btn btn-primary">Delete </button>
                    <button type="button" id="close_delete_btn" class="btn btn-danger"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="Add_Specialities_details" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Partner Company</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="addJobForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Url</label>
                                <input type="text" class="form-control" name="url">
                                <input type="hidden" class="form-control" name="type" value="addPartner" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" class="form-control" name="image" accept="image/*" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Add</button>
                </form>
            </div>
        </div>
    </div>
</div>


<?php include('include/footer.php') ?>
<script>
    function deleteJob(id){
        $("#delete_btn").attr("delete-data", id);
    }

    $("#delete_btn").click(function() {
        var id = $(this).attr("delete-data");
        console.log(id);
        $.ajax({
            url: '../settings/api/partnerCompanyApi.php',
            type: 'POST',
            data: {
                type : 'deletePartner',
                id:id
            },
            dataType: 'json',
            success: function (response) {
                $('#close_delete_btn').click();
                $("#tr"+id).remove();
                notyf.success(response.message);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

    $('#addJobForm').submit(function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: '../settings/api/partnerCompanyApi.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });
</script>