<?php
$current_page = "jobs";
include("../settings/conn.php");
$jobs = $conn->prepare("SELECT * FROM `jobs`");
$jobs->execute();
$jobs = $jobs->fetchAll(PDO::FETCH_ASSOC);

$companys = $conn->prepare("SELECT * FROM `company`");
$companys->execute();
$companys = $companys->fetchAll(PDO::FETCH_ASSOC);


include("include/navbar.php");
?>
<style>
    .Active {
        color: green;
    }

    .Inactive {
        color: red;
    }
</style>
<main style="margin-top: 100px;">
    <div class="container pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between"
                style="padding: 0 0 40px 0; font-size: 25px;align-items: center;">
                <p class="fw-bold">Job List</p>
                <a href="#Add_Specialities_details" data-bs-toggle="modal" class="btn btn-primary">Add</a>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        Title
                    </th>
                    <th>
                        Description
                    </th>
                    <th>
                        Company Name
                    </th>
                    <th>
                        Location
                    </th>
                    <th>
                        Reference
                    </th>
                    <th>
                        Job Type
                    </th>
                    <th>
                        Sallery Upto
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 0;
                foreach ($jobs as $key => $value) {
                    $status = $value['status'] == 1 ? 'Active' : 'Inactive';
                    $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ?");
                    $company->execute([$value['company_id']]);
                    $company = $company->fetch(PDO::FETCH_ASSOC);
                    $value['company'] = $company;
                    $data = base64_encode(json_encode($value));
                    echo '<tr id="tr'.$value['id'].'">
                                <td>' . ++$i . '</td>
                                <td>' . $value['title'] . '</td>
                                <td>' . substr($value['description'], 0, 70) . '....</td>
                                <td>' . $company['company'] . '</td>
                                <td>' . $value['location'] . '</td>
                                <td>' . $value['reference'] . '</td> 
                                <td>' . $value['job_type'] . '</td>
                                 <td>' . $value['salary'] . '</td>
                                <td class="' . $status . '">' . $status . '</td>
                                <td style="display: flex;">
                                    <button class="btn btn-sm bg-success-light" onclick="editJobs(\'' . $data . '\')">Edit</button>
                                    <a href="#delete_modal" data-bs-toggle="modal"  class="btn btn-sm bg-danger-light" onclick="deleteJob('.$value['id'].')">Delete</a>
                                </td>
                            </tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<div class="modal fade" id="Add_Specialities_details" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload Job</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="addJobForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Title</label>
                                <input type="text" class="form-control" name="job_title" required>
                                <input type="hidden" class="form-control" name="type" value="addJob" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Location</label>
                                <input type="text" class="form-control" name="location" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                <select class="form-control" name="Company_id" required>
                                    <option value="" selected disabled hidden>Select Company</option>
                                    <?php
                                    foreach ($companys as $company) {

                                        echo '<option value="' . $company['id'] . '">' . $company['company'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Type</label>
                                <select class="form-control" name="job_type" required>
                                    <option value="" selected disabled hidden>Select Job Type</option>
                                    <option value="sailor">Sailor</option>
                                    <option value="officer">Officer</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" class="form-control" name="description" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Reference</label>
                                <input type="text" class="form-control" name="reference" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Salary Upto</label>
                                <input type="number" class="form-control" name="salary" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Upload Job</button>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="edit_Specialities_details" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Job</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i
                        class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="updateJobForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Title</label>
                                <input type="text" class="form-control" name="job_title" id="job_title" required>
                                <input type="hidden" name="job_id" id="job_id" required>
                                <input type="hidden" class="form-control" name="type" value="updateJob" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Location</label>
                                <input type="text" class="form-control" name="location" id="location" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                <select class="form-control" name="Company_id" id="Company_id" required>
                                    <option value="" selected disabled hidden>Select Company</option>
                                    <?php
                                    foreach ($companys as $company) {

                                        echo '<option value="' . $company['id'] . '">' . $company['company'] . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Type</label>
                                <select class="form-control" id="job_type" name="job_type" required>
                                    <option value="" selected disabled hidden>Select Job Type</option>
                                    <option value="sailor">Sailor</option>
                                    <option value="officer">Officer</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" class="form-control" name="description" id="description" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Reference</label>
                                <input type="text" class="form-control" name="reference" id="reference" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status" id="status" class="form-control" >
                                    <option value="0">Inactive</option>
                                    <option value="1">Active</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Salary Upto</label>
                                <input type="number" class="form-control" name="salary" id="salary" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Upload Job</button>
                </form>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="delete_modal" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-content p-2">
                    <h4 class="modal-title">Delete</h4>
                    <p class="mb-4">Are you sure want to delete?</p>
                    <button type="button" id="delete_btn" delete-data="0" class="btn btn-primary">Delete </button>
                    <button type="button" id="close_delete_btn" class="btn btn-danger"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('include/footer.php') ?>
<script>

    function editJobs(data) {
        var data = JSON.parse(atob(data));
        console.log(data);
        $('#edit_Specialities_details').modal('show');
        $('#job_title').val(data.title);
        $('#location').val(data.location);
        $('#description').val(data.description);
        $('#reference').val(data.reference);
        $('#Company_id').val(data.company_id);
        $('#job_type').val(data.job_type);
        $('#job_id').val(data.id);
        $('#status').val(data.status);
        $('#salary').val(data.salary);
    }

    $('#addJobForm').submit(function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: '../settings/api/jobApi.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

    $('#updateJobForm').submit(function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: '../settings/api/jobApi.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    })

    function deleteJob(id){
        $("#delete_btn").attr("delete-data", id);
    }

    $("#delete_btn").click(function() {
        var id = $(this).attr("delete-data");
        console.log(id);
        $.ajax({
            url: '../settings/api/jobApi.php',
            type: 'POST',
            data: {
                type : 'deleteJob',
                job_id:id
            },
            dataType: 'json',
            success: function (response) {
                $('#close_delete_btn').click();
                $("#tr"+id).remove();
                notyf.success(response.message);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    });

</script>