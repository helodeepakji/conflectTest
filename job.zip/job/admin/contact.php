<?php
$current_page = "contact";
include("../settings/conn.php");
$contacts = $conn->prepare("SELECT * FROM `contact` ORDER BY `created_at` DESC");
$contacts->execute();
$contacts = $contacts->fetchAll(PDO::FETCH_ASSOC);
include("include/navbar.php");
?>
<style>
    .Read{
        color: green;
    }
    .Unread{
        color: red;
    }
</style>
<main style="margin-top: 100px;">
    <div class="container pt-5 p-2">
        <div class="container">
            <div class="d-flex justify-content-between" style="padding: 0 0 40px 0; font-size: 25px;align-items: center;">
                <p class="fw-bold">Contact Us</p>
                <a href="#Add_Specialities_details" data-bs-toggle="modal" class="btn btn-primary">Add</a>
            </div>
        </div>
        <table id="datatable">
            <thead>
                <tr>
                    <th>
                        #
                    </th>
                    <th>
                        First Name
                    </th>
                     <th>
                        Last Name
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Phone
                    </th>
                    <th>
                        Message
                    </th>
                    <th>
                        Status
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        Action
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 0;
                    foreach ($contacts as $value) {
                        $status = $value['status'] == 1 ? 'Read' : 'Unread';
                        $btnstatus = $value['status'] == 0 ? '<button class="btn btn-sm bg-success-light" style="background: #009c00;color: white;" onclick="readContact('.$value['id'].')"> Read </button>' : '<button class="btn btn-sm bg-danger-light" style="background:#ee758a;color: white;" onclick="unReadContact('.$value['id'].')">Unread </button>';
                        $data = base64_encode(json_encode($value));
                        echo '<tr id="tr'.$value['id'].'">
                                <td>'.++$i.'</td>
                                <td>'.$value['first_name'].'</td>
                                <td>'.$value['last_name'].'</td>
                                <td>'.$value['email'].'</td>
                                <td>'.$value['phone'].'</td>
                                <td>'.$value['message'].'</td>
                                <td class="'.$status.'" id="status_'.$value['id'].'">'.$status.'</td>
                                <td>'.date("d M, Y h:i A", strtotime($value['created_at'])).'</td>
                                <td id="btn_'.$value['id'].'">'.$btnstatus.'</td>
                            </tr>';
                    }
                ?>
            </tbody>
        </table>
    </div>
</main>


<?php include('include/footer.php') ?>
<script>
    
    function readContact(id){
        $.ajax({
            url: 'include/api/contactApi.php',
            type: 'Post',
            data: {
                id : id,
                type : 'readContact'
            },
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                console.log(response);
                $('#status_'+id).text(response.changeStatus);
                $('#status_'+id).css('color' , 'green');
                $('#btn_'+id).html(`<button class="btn btn-sm bg-danger-light" style="background:#ee758a;color: white;" onclick="unReadContact(${id})">Unread </button>`);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    }
    
    function unReadContact(id){
        $.ajax({
            url: 'include/api/contactApi.php',
            type: 'Post',
            data: {
                id : id,
                type : 'unReadContact'
            },
            dataType: 'json',
            success: function (response) {
                notyf.success(response.message);
                console.log(response);
                $('#status_'+id).text(response.changeStatus);
                $('#status_'+id).css('color' , 'red');
                $('#btn_'+id).html(`<button class="btn btn-sm bg-success-light" style="background: #009c00;color: white;" onclick="readContact(${id})"> Read </button>`);
            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    }

</script>