<?php
include("settings/conn.php");
$date = isset($_GET['date']) ? $_GET['date'] : '';
$date = strtotime($date);
$date = date('Y-m-d', $date);
$job = $conn->prepare("SELECT * FROM `jobs` WHERE `title` LIKE ? AND `location` LIKE ? AND `job_type` LIKE ? AND `status` = 1 AND DATE(`created_at`) >= ?");
$job->execute(['%' . $_GET['job-type'] . '%', '%' . $_GET['location'] . '%', '%' . $_GET['job_type'] . '%',$date]);
$job = $job->fetchAll(PDO::FETCH_ASSOC);

include("settings/include/navbar.php");
?>
<style>
    a {
        text-decoration: none;
        color: black;
    }

    a:hover {
        text-decoration: none;
        color: black;
    }

    main {
        margin-top: 100px;
    }

    main .container {
        padding: 40px;
    }

    .form-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .search-form {
        display: flex;
        align-items: center;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        justify-content: space-between;
    }

    .search-input {
        flex: 1;
        padding: 8px;
        border: none;
        border-radius: 5px;
        margin-right: 5px;
    }

    .areab {
        width: 100%;
        display: flex;
        align-items: center;
    }

    .search-button {
        background-color: #007BFF;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 8px 12px;
        cursor: pointer;
    }

    .header {
        background-color: #c7c7c7;
        padding: 10px 100px;
    }

    main form i {
        color: #007bff;
        margin: 0 10px;
        font-size: 25px;
    }

    main .job_list {
        margin: 50px 0;
    }

    main .data {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    main p {
        margin: 0;
    }

    main p.company_name {
        font-weight: 600;
    }

    main p.location_details {
        color: #8b8b8b;
    }

    main .card-body {
        background-image: linear-gradient(248deg, #cdeaff, #ff00000d);
    }

    select:focus, input:focus {
        outline: none; /* Remove the focus/active border */
    }

    @media screen and (max-width : 1080px) {
        .search-form {
            justify-content: center;
        }

        /* .search-input {
            width: 100px;
        } */
    }

    input, select {
        width: 100%;
        margin: 10px;
    }

    @media screen and (max-width : 400px) {
        main .container {
            padding: 10px;
        }
        .bigduv{
            display: flex;
            flex-direction: column;
        }
    }
    
    @media screen and (max-width : 750px) {
        .search-form {
            display: flex;
            align-items: stretch;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            justify-content: space-between;
            flex-direction: column;
        }
    }
    .salary{
        font-weight: 400 !important;
    }
</style>
<main>
    <div class="header">
        <h5>Find Jobs</h5>
    </div>
    <div class="container">
        <div class="form">
            <form class="search-form" action="job.php" method="get">
                <div class="areab bigduv">
                    <div class="areab">
                        <i class="fas fa-search"></i>
                        <input class="search-input" type="text" value="<?php echo $_GET['job-type'] ?? '' ?>" name="job-type" placeholder="Job Type">
                    </div>
                    <div class="areab">
                        <i class="fas fa-map-marker-alt"></i>
                        <input class="search-input" type="text" value="<?php echo $_GET['location'] ?? '' ?>" name="location"  placeholder="Location">
                    </div>
                </div>
                <div class="areab bigduv">
                    <div class="areab">
                        <i class="fa-solid fa-calendar-days"></i>
                        <input class="search-input" type="date" value="<?php echo $_GET['date'] ?? '' ?>" name="date"  placeholder="Posted Date">
                    </div>
                    <div class="areab">
                        <i class="fas fa-map-marker-alt"></i>
                        <select class="form-control search-input" name="job_type">
                            <option value="" selected>Select Job Type</option>
                            <option value="sailor" <?php echo $_GET['job_type'] == 'sailor' ? 'selected' : '' ?>>Sailor</option>
                            <option value="officer" <?php echo $_GET['job_type'] == 'officer' ? 'selected' : '' ?>>Officer</option>
                        </select>
                    </div>
                </div>
                <button class="search-button" type="submit">
                    Find Job
                </button>
            </form>
        </div>
        <div class="job_list">
            <div class="row">
                <?php
                if (count($job) == 0) {
                    echo '<div class="col-12 col-md-6 col-lg-4 d-flex mb-2">
                            <div class="card flex-fill">
                                <div class="card-body">
                                <h5 style="padding: 20px 0;">No Jobs</h5>
                        </div></div></div>';
                }

                foreach ($job as $value) {
                    $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ?");
                    $company->execute([$value['company_id']]);
                    $company = $company->fetch(PDO::FETCH_ASSOC);
                    ?>
                    <div class="col-12 col-md-6 col-lg-4 d-flex mb-2">
                        <div class="card flex-fill">
                            <div class="card-body">
                                <a href="job-details.php?id=<?php echo $value['id'] ?>">
                                    <h5>
                                        <?php echo $value['title'] ?>
                                    </h5>
                                </a>
                                <div class="data">
                                    <img src="<?php echo $company['image'] ?>" width="50px" alt="">
                                    <div class="location">
                                        <p class="company_name">
                                            <?php echo $company['company'] ?>
                                        </p>
                                        <p class="company_name salary">
                                            Salary Upto : Rs. <?php echo $value['salary'] ?>
                                        </p>
                                        <p class="location_details"><i class="fas fa-map-marker-alt"></i>
                                            <?php echo $value['location'] ?>
                                        </p>
                                        <p class="location_details">Post Date :
                                            <?php echo date("d M, Y", strtotime($value['created_at'])); ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</main>
<?php include("settings/include/footer.php"); ?>