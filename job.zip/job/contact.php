<?php
include("settings/conn.php");
include("settings/include/navbar.php");
?>
<style>
    main {
        background-image: url('images/contact.avif');
        background-repeat: no-repeat;
        height: 500px;
        display: flex;
        align-items: center;
        background-size: contain;
        background-color: #ffffff;
        background-position-x: 15%;
    }

    main .left,
    main .right {
        width: 50%;
        display: grid;
        justify-items: center;
    }

    .login-right-wrap {
        width: 400px;
    }

    textarea#message {
        width: 100%;
    }

    @media screen and (max-width : 800px) {
        main {
            flex-direction: column;
            height: auto;
        }

        main .left {
            height: 300px;
        }

        main .left,
        main .right {
            width: 100%;
        }
    }

    @media screen and (max-width : 500px) {
        .login-right-wrap {
            width: 95%;
        }
    }
</style>
<main style="margin-top:100px">
    <div class="left">
    </div>
    <div class="right">
        <div class="login-right-wrap">
            <h3>Contact Us</h3>
            <p class="account-subtitle"></p>
            <form id="contactform" method="post">
                <div class="form-group">
                    <input class="form-control" type="text" name="first_name" placeholder="First Name" required>
                    <input type="hidden" name="type" value="addContact">
                </div>
                <div class="form-group">
                    <input class="form-control" type="text" name="last_name" placeholder="Last Name" required>
                </div>
                <div class="form-group">
                    <input class="form-control" type="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input class="form-control" type="number" name="phone" id="phone" placeholder="Phone No" required>
                </div>
                <div class="form-group">
                    <textarea class="form-control" name="message" id="exampleFormControlTextarea1" rows="3"
                        placeholder="Message..." required></textarea>
                </div>
                <div class="form-group">
                    <button class="btn btn-primary w-100" type="submit">Contact Us</button>
                </div>
            </form>
        </div>
    </div>
</main>
<div class="container my-5">
        <h2 class="text-center mb-4">Offices-In-Charge</h2>

        <div class="row">
            <div class="col-lg-6">
                <h4>New Delhi</h4>
                <p>Indian Naval Placement Agency<br>
                    Directorate of Ex-Servicemen Affairs, Integrated Headquarters Ministry of Defence (Navy), Room No 004,
                    Talkatora Stadium Annexe, New Delhi 110004<br>
                    +91 9654556416 , 011-24121687<br>
                    <a href="mailto:inpa@navy.gov.in">inpa@navy.gov.in</a>
                </p>
            </div>

            <div class="col-lg-6">
                <h4>Mumbai</h4>
                <p>The Logistics Officer-in-Charge (for NAVPEN Placement cell)<br>
                    Naval Pension Office, INS Tanaji, Sion-Trombay Road, Mankhurd Mumbai - 400 088<br>
                    022-25075600, 25075602<br>
                    <a href="mailto:navpenplacement@gmail.com">navpenplacement@gmail.com</a>
                </p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-lg-6">
                <h4>Kochi</h4>
                <p>SNC Placement cell (SNCPC)<br>
                    HQSNC Naval Base, Kochi - 682 004<br>
                    0484-2662435, 0848-2668319<br>
                    <a href="mailto:snccrto@navy.gov.in">snccrto@navy.gov.in</a>
                </p>
            </div>

            <div class="col-lg-6">
                <h4>Vizag</h4>
                <p>ENC Placement Cell (ENCPC)<br>
                    HQENC INCS Complex, Naval Base, Visakhapatnam - 530 014<br>
                    0891-2752771<br>
                    <a href="mailto:encplacementcell@gmail.com">encplacementcell@gmail.com</a>
                </p>
            </div>
        </div>
    </div>
<?php include("settings/include/footer.php"); ?>
<script>
    $('#contactform').submit(function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        var phone = $('#phone').val();
        if(phone.length == 10){
            $.ajax({
                url: 'settings/api/contactApi.php',
                type: 'POST',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                dataType: 'json',
                success: function (response) {
                    notyf.success(response.message);
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                },
                error: function (xhr, status, error) {
                    var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                    notyf.error(errorMessage);
                }
            });
        }else{
            notyf.error("Phone no must be 10 digits");
        }
    });
</script>