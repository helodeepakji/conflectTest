<?php

include("settings/conn.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($_POST["branch"] != '' && $_POST["qualification"] != '' && $_POST["password"] != '' && $_POST["email"] != '' && $_POST["phone"] != '' && $_POST["first_name"] != '' && $_POST["last_name"] != '' && $_POST["rank"] != '') {

        if(strlen($_POST["phone"]) != 10){
            $error =  "Phone no must be 10 digits.";
        }else{

            $check = $conn->prepare('SELECT * FROM `users` WHERE `email` = ? OR `phone` = ?');
            $check->execute([$_POST["email"], $_POST["phone"]]);
            $check = $check->fetch(PDO::FETCH_ASSOC);
            if (!$check) {
    
                if(isset($_FILES["profile"]['name']) && $_FILES["profile"]['name'] != ''){
                    $profile = basename($_FILES['profile']['name']);
                    $uploadPath = 'upload/' . $profile;
                    move_uploaded_file($_FILES['profile']['tmp_name'], $uploadPath);
                    $profile_link = $socket . 'upload/' . $profile;
                }else{
                    $profile_link = '';
                }
                
                if(isset($_FILES["cv"]['name']) && $_FILES["cv"]['name'] != ''){
                    $cv = basename($_FILES['cv']['name']);
                    $uploadPath = 'upload/' . $cv;
                    move_uploaded_file($_FILES['cv']['tmp_name'], $uploadPath);
                    $cvfile = $socket . 'upload/' . $cv;
                }else{
                    $cvfile = '';
                }
    
    
                $hashpassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $users = [$_POST["first_name"], $_POST["last_name"], $_POST["email"], $_POST["phone"], $profile_link, $cvfile, $_POST["rank"], $_POST["qualification"], $_POST["branch"], $hashpassword];
    
                $sql = $conn->prepare('INSERT INTO `users`(`first_name`, `last_name`, `email`, `phone`, `profile`, `cv`, `rank`, `qualification`, `branch` , `password`) VALUES ( ? , ? , ? ,  ? , ? , ? , ? , ? , ? , ?)');
                $result = $sql->execute($users);
                if ($result) {
                    $warning =  "Your Registation under verfication.";
                } else {
                    $error =  "Something Went Wrong.";
                }
            } else {
                $warning =  "User Already exist.";
            }
        }

    } else {
        $error =  "Fill All Required Field.";
    }
}

?>

<?php include("settings/include/navbar.php"); ?>
<style>
    main {
        background-image: url('https://www.joinindiannavy.gov.in/images/home_banner/home_banner_1.jpg');
        background-repeat: no-repeat;
        background-size: cover;
        font-family: Arial, sans-serif;
        width: 100%;
        padding: 50px;
    }

    .login-right,
    .login-left {
        width: 50%;
    }

    .login-right {
        padding: 40px;
        width: 600px;
        background: white;
        /* text-align: center; */
    }

    .login-or {
        text-align: center;
    }

    .row {
        justify-content: space-between;
    }

    @media screen and (max-width : 500px) {
        main {
            padding: 10px;
        }

        .login-right {
            padding: 20px;
        }
    }
</style>
<main style="margin-top: 100px;">
    <div class="container">
        <div class="row">
            <div class="login-right">
                <?php
                if(isset($error)) {
                    echo '<div class="alert alert-danger" role="alert">
                            '.$error.'
                        </div>';
                }
                if(isset($warning)) {
                    echo '<div class="alert alert-warning" role="alert">
                            '.$warning.'
                        </div>';
                }
                ?>
                <div class="login-right-wrap">
                    <h3>Register</h3>
                    <form action="register.php" method="post" enctype="multipart/form-data">

                        <div class="row form-row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>First Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" value="<?php echo $_POST['first_name'] ?? '' ?>" name="first_name" required>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Last Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" value="<?php echo $_POST['last_name'] ?? '' ?>"  name="last_name" required> 
                                </div>
                            </div>
                        </div>
                        <div class="row form-row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Email <span class="text-danger">*</span></label>
                                    <input class="form-control" type="email" value="<?php echo $_POST['email'] ?? '' ?>"  name="email" required>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Phone <span class="text-danger">*</span></label>
                                    <input class="form-control" value="<?php echo $_POST['phone'] ?? '' ?>" type="number" name="phone" required>
                                </div>
                            </div>
                        </div>
                        <div class="row form-row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Rank <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text" value="<?php echo $_POST['rank'] ?? '' ?>" name="rank" required>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Branch <span class="text-danger">*</span></label>
                                    <select class="form-control" name="branch" required>
                                        <option value="">Select Branch</option>
                                        <option value="Navy">Navy</option>
                                        <option value="Coast Guard">Coast Guard</option>
                                        <option value="Marines">Marines</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row form-row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Qualification <span class="text-danger">*</span></label>
                                    <input class="form-control" value="<?php echo $_POST['qualification'] ?? '' ?>" type="text" name="qualification" required>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Set Password <span class="text-danger">*</span></label>
                                    <input class="form-control" type="password" name="password" required>
                                </div>
                            </div>
                        </div>
                        <div class="row form-row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Upload Profile</label>
                                    <input class="form-control" type="file" name="profile" accept="image/png, image/gif, image/jpeg" >
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label>Upload CV</label>
                                    <input class="form-control" type="file" name="cv" accept=".pdf"
                                        placeholder="Upload CV">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary w-100" type="submit">Register</button>
                        </div>
                    </form>
                    <div class="text-center dont-have">Don you have an account? <a href="login.php">Login now</a></div>
                </div>
            </div>
            <div class="login-left">
            </div>
        </div>
    </div>
</main>
<?php include("settings/include/footer.php"); ?>
