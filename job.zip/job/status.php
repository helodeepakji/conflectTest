<style>
    .section {
        display: flex;
        align-items: center;
        justify-content: space-evenly;
        padding: 40px;
        background-color: #f6f6f6;
    }

    .section .box {
        width: 300px;
        background-color: white;
        padding: 15px;
        border-radius: 15px;
        display: flex;
        justify-content: space-around;
        align-items: center;
    }
    .section .box:hover{
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }

    .section .box .img {
        background: #cde3f6;
        padding: 10px;
        width: 70px;
        border-radius: 10px;
    }

    .section .textbox {
        width: 100%;
        padding: 0 30px;
    }

    @media screen and (max-width : 700px) {
        .section {
            flex-direction: column;
        }
    }
</style>
<div class="section">
    <div class="box mt-2">
        <div class="img">
            <img src="images/icon/office-building.png" width="50px" alt="">
        </div>
        <div class="textbox">
            <h5><?php echo $countLiveJobs ?></h5>
            <p>Live Jobs</p>
        </div>
    </div>
    <div class="box mt-2">
        <div class="img">
            <img src="images/icon/suitcase.png" width="50px" alt="">
        </div>
        <div class="textbox">
            <h5><?php echo $countCompany ?></h5>
            <p>Company</p>
        </div>
    </div>
    <div class="box mt-2">
        <div class="img">
            <img src="images/icon/team.png" width="50px" alt="">
        </div>
        <div class="textbox">
            <h5><?php echo $countUser; ?></h5>
            <p>Users</p>
        </div>
    </div>
    <div class="box mt-2">
        <div class="img">
            <img src="images/icon/office-building.png" width="50px" alt="">
        </div>
        <div class="textbox">
            <h5><?php echo $countLiveJobs ?></h5>
            <p>New Jobs</p>
        </div>
    </div>
</div>