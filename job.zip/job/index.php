<?php
include("settings/conn.php");
$job = $conn->prepare("SELECT * FROM `jobs` WHERE `status` = 1");
$job->execute();
$job = $job->fetchAll(PDO::FETCH_ASSOC);
$countLiveJobs = count($job);

$company = $conn->prepare("SELECT * FROM `company`");
$company->execute();
$company = $company->fetchAll(PDO::FETCH_ASSOC);
$countCompany = count($company);

$user = $conn->prepare("SELECT * FROM `users`");
$user->execute();
$user = $user->fetchAll(PDO::FETCH_ASSOC);
$countUser = count($user);

$uploadJob = true;
include("settings/include/navbar.php");
?>
<style>
    main {
        margin-top: 100px;
        background-image: url('images/hero-image.png');
        background-repeat: no-repeat;
        background-position: right;
        height: 500px;
        display: flex;
        align-items: center;
        background-position-x: 80%;
        background-size: contain;
        background-color: #f8f7f6;
    }

    main .left,
    main .right {
        width: 50%;
        padding: 60px;
        text-align: center;
    }

    main .left {
        width: 100%;
    }

    main .left h1 {
        font-size: 50px;
    }

    .form-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }

    .search-input {
        /* width: 100px; */
    }

    .search-form {
        display: flex;
        align-items: center;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background: white;
        justify-content: space-between;
    }

    .search-input {
        flex: 1;
        padding: 8px;
        border: none;
        border-radius: 5px;
        margin-right: 5px;
    }

    .search-button {
        background-color: #007BFF;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 8px 12px;
        cursor: pointer;
    }

    main .left form input:focus {
        background-color: transparent;
        border: 0px solid;
    }

    main .left form i {
        color: #007bff;
        font-size: 20px;
    }

    select:focus,
    input:focus {
        outline: none;
        /* Remove the focus/active border */
    }

    @media screen and (max-width : 1080px) {
        main {
            background-position-y: 0;
            flex-direction: column-reverse;
            height: auto;
        }

        main .left,
        main .right {
            width: 100%;
            padding: 10px;
        }

        .search-form {
            justify-content: center;
        }

        main .right {
            height: 400px;
        }

        .search-input {
            /* width: 100%; */
        }

        main .left h1 {
            font-size: 30px;
        }
    }

    @media screen and (max-width : 600px) {
        .search-form {
            flex-direction: column;
        }

        .areab {
            padding: 10px;
            margin: 10px;
            width: 100%;
        }
    }
</style>

<main>
    <div class="left">
        <h1>Find a job that suits your interest & skills.</h1>
        <p>Assist Indian Navy personnel in their transition to civilian careers.</p>
        <form class="search-form" action="job.php" method="get">
            <div class="areab d-flex align-items-center">
                <i class="fas fa-search"></i>
                <input class="search-input" type="text" name="job-type" placeholder="Search Job">
            </div>
            <div class="areab d-flex align-items-center">
                <i class="fas fa-map-marker-alt"></i>
                <input class="search-input" type="text" name="location" placeholder="Location">
            </div>
            <div class="areab d-flex align-items-center">
                <i class="fas fa-map-marker-alt"></i>
                <select class="form-control search-input" name="job_type">
                    <option value="" selected>Select Job Type</option>
                    <option value="sailor">Sailor</option>
                    <option value="officer">Officer</option>
                </select>
            </div>
            <button class="search-button" type="submit">
                Find Job
            </button>
        </form>
    </div>
    <div class="right">
    </div>
</main>

<div class="modal fade" id="upload_job_form" aria-hidden="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Upload Job</h5>
                <a type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></a>
            </div>
            <div class="modal-body">
                <form id="updateJobForm">
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Title</label>
                                <input type="text" class="form-control" name="job_title" id="job_title" required>
                                <input type="hidden" class="form-control" name="type" value="addJob" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Location</label>
                                <input type="text" class="form-control" name="location" required>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company</label>
                                <select class="form-control" name="Company_id" id="Company_id" required>
                                    <option value="" selected disabled hidden>Select Company</option>
                                    <?php
                                    foreach ($company as $value) {

                                        echo '<option value="' . $value['id'] . '">' . $value['company'] . '</option>';
                                    }
                                    ?>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Job Type</label>
                                <select class="form-control" name="job_type" required>
                                    <option value="" selected disabled hidden>Select Job Type</option>
                                    <option value="sailor">Sailor</option>
                                    <option value="officer">Officer</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row form-row" id="add_company" style="display:none">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company Name</label>
                                <input type="text" class="form-control" name="company_name">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Company Details</label>
                                <input type="text" class="form-control" name="company_details">
                            </div>
                        </div>
                    </div>
                    <div class="row form-row" id="add_company_logo" style="display:none">
                        <div class="col-12 col-sm-12">
                            <div class="form-group">
                                <label>Company Logo</label>
                                <input type="file" class="form-control" name="company_logo">
                            </div>
                        </div>
                    </div>
                    <div class="row form-row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" class="form-control" name="description" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Reference</label>
                                <input type="text" class="form-control" name="reference" required>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label>Salary Upto</label>
                                <input type="number" class="form-control" name="salary" required>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Upload Job</button>
                </form>
            </div>
        </div>
    </div>
</div>


<?php
include("settings/include/notification.php");
include("status.php");
?>
<style>
    #ourclients {
        display: block;
        margin-left: auto;
        margin-right: auto;
        background: #f9f9f9;
        padding-bottom: 30px;
        height: 250px;
    }

    #ourclients .clients-wrap {
        display: block;
        width: 95%;
        margin: 0 auto;
        overflow: hidden;
    }

    #ourclients .clients-wrap ul {
        display: block;
        list-style: none;
        position: relative;
        margin-left: auto;
        margin-right: auto;
    }

    #ourclients .clients-wrap ul li {
        display: block;
        float: left;
        position: relative;
        width: 220px;
        height: 100px;
        line-height: 100px;
        text-align: center;
    }

    #ourclients .clients-wrap ul li img {
        vertical-align: middle;
        max-width: 100%;
        width: 150px;
        max-height: 100%;
        -webkit-transition: 0 linear left;
        -moz-transition: 0 linear left;
        transition: 0 linear left;
    }

    #ourclients h3 {
        border-bottom: 2px solid #3399ff;
        width: 150px;
        padding: 10px;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<div id="ourclients">
    <center>
        <h3>Partner Companies</h3>
    </center>
    <div class="clients-wrap">
        <ul id="clientlogo" class="clearfix">
            <?php
                $partners = $conn->prepare("SELECT * FROM `partners`");
                $partners->execute();
                $partners = $partners->fetchAll(PDO::FETCH_ASSOC);
                foreach ($partners as $value) {
            
                    echo '<li>
                    <a href="'.$value['url'].'">
                    <img src="'.$value['image'].'" alt="Logo">
                    </a>
                </li>';

                }
            ?>
        </ul>
    </div>
</div>

<?php
include("flow.php");
?>
<?php include("settings/include/footer.php"); ?>
<script>

    $('#Company_id').change(() => {
        var Company_id = $('#Company_id').val();
        if (Company_id == 'other') {
            $('#add_company').css('display', 'flex');
            $('#add_company_logo').css('display', 'flex');
        } else {
            $('#add_company').css('display', 'none');
            $('#add_company_logo').css('display', 'none');
        }
    });

    $('#updateJobForm').submit(function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: 'settings/api/jobApi.php',
            type: 'POST',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function(response) {
                notyf.success(response.message);
                setTimeout(() => {
                    location.reload();
                }, 500);
            },
            error: function(xhr, status, error) {
                var errorMessage = xhr.responseJSON ? xhr.responseJSON.message : "Something went wrong.";
                notyf.error(errorMessage);
            }
        });
    })
    $(function() {
        var $clientslider = $('#clientlogo');
        var clients = $clientslider.children().length;
        var clientwidth = (clients * 220);
        $clientslider.css('width', clientwidth);
        var rotating = true;
        var clientspeed = 1800;
        var seeclients = setInterval(rotateClients, clientspeed);
        $(document).on({
            mouseenter: function() {
                rotating = false;
            },
            mouseleave: function() {
                rotating = true;
            }
        }, '#ourclients');

        function rotateClients() {
            if (rotating != false) {
                var $first = $('#clientlogo li:first');
                $first.animate({
                    'margin-left': '-220px'
                }, 2000, function() {
                    $first.remove().css({
                        'margin-left': '0px'
                    });
                    $('#clientlogo li:last').after($first);
                });
            }
        }
    });
</script>