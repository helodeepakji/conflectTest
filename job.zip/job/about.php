<?php
include("settings/conn.php");
include("settings/include/navbar.php");
?>
<style>
    .card-img-top {
        margin: auto;
        padding: 10px;
        width: 100px;
        background: #eef9ee;
        border-radius: 50%;
    }

    #about-hero {
        background-image: url(images/spotlight-image.jpg);
        background-repeat: no-repeat;
        background-size: cover;
        color: white;
        -webkit-text-stroke: 0.4px black;
    }
</style>
<main style="margin-top:120px">
    <div class="container my-5">
        <div class="row p-4" id="about-hero">
            <div class="col-lg-12">
                <h2 class="text-center">ABOUT INPA</h2>
                <h4 class="text-center">
                    WELCOME TO THE INDIAN NAVAL PLACEMENT AGENCY
                </h4>
                <p>
                    The Indian Navy established the Indian Naval Placement Agency (INPA) on 18 Feb 2006 under the aegis
                    of Directorate of Ex-Servicemen Affairs at Naval Headquarters. Subsequently, Command Placement Cells
                    were established at Mumbai, Kochi, and Vishakhapatnam under the respective Command Headquarters.

                    The primary aim of INPA is to enhance second career opportunities for retiring / retired naval
                    personnel in the corporate / private sector. While retiring/ retired personnel are required to pay a
                    nominal fee for registration, the INPA and Placement Cells render free services to the veer naris
                    (i.e., widows of naval personnel). In pursuit of this aim, INPA and the Placement Cells undertaken
                    the following activities:-
                <ol>
                    <li>Facilitate recruitment of retired / retiring naval personnel through operation of the placement
                        portal at https://indiannavy.nic.in/inpa/.</li>
                    <li>Conduct of Job Fairs in collaboration with Directorate General Resettlement (DGR) and other
                        Services.</li>
                    <li>Enhance placement of retiring / retired naval personnel through engagement with professional HR
                        agencies, corporate houses, and business forums.</li>
                    <li>Facilitate awareness among the retired / retiring naval personnel of the skill requirements of
                        the industry and guidance on preparation for re-employment in corporate / private sector.</li>
                    <li>Facilitate recruitment of retired / retiring naval personnel in govt / semi government
                        organisations.</li>
                    <li>Progress initiatives to upgrade / certify skill sets of retired / retiring naval personnel.</li>
                </ol>
                </p>
            </div>
        </div>
    </div>
    <style>
    #ourclients {
        display: block;
        margin-left: auto;
        margin-right: auto;
        background: #f9f9f9;
        padding-bottom: 30px;
        height: 250px;
    }

    #ourclients .clients-wrap {
        display: block;
        width: 95%;
        margin: 0 auto;
        overflow: hidden;
    }

    #ourclients .clients-wrap ul {
        display: block;
        list-style: none;
        position: relative;
        margin-left: auto;
        margin-right: auto;
    }

    #ourclients .clients-wrap ul li {
        display: block;
        float: left;
        position: relative;
        width: 220px;
        height: 100px;
        line-height: 100px;
        text-align: center;
    }

    #ourclients .clients-wrap ul li img {
        vertical-align: middle;
        max-width: 100%;
        width: 150px;
        max-height: 100%;
        -webkit-transition: 0 linear left;
        -moz-transition: 0 linear left;
        transition: 0 linear left;
    }

    #ourclients h3 {
        border-bottom: 2px solid #3399ff;
        width: 150px;
        padding: 10px;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<div id="ourclients">
    <center>
        <h3>Partner Companies</h3>
    </center>
    <div class="clients-wrap">
        <ul id="clientlogo" class="clearfix">
            <?php
                $partners = $conn->prepare("SELECT * FROM `partners`");
                $partners->execute();
                $partners = $partners->fetchAll(PDO::FETCH_ASSOC);
                foreach ($partners as $value) {
            
                    echo '<li>
                    <a href="'.$value['url'].'">
                    <img src="'.$value['image'].'" alt="Logo">
                    </a>
                </li>';

                }
            ?>
        </ul>
    </div>
</div>

    <div class="container my-5">
        <div class="card-deck">
            <div class="card">
                <img src="images/icon/magnifying-glass.png" class="card-img-top" alt="Executive Search">
                <div class="card-body">
                    <h5 class="card-title">Executive Search</h5>
                    <p class="card-text">Are you a recruiter looking for the ideal candidate? Search our database of
                        nearly 40,000 naval personnel by skillset and location.</p>
                </div>
            </div>
            <div class="card">
                <img src="images/icon/career-path.png" class="card-img-top" alt="Career Advisory">
                <div class="card-body">
                    <h5 class="card-title">Career Advisory</h5>
                    <p class="card-text">Job seekers, transitioning from the Navy to the private sector is now easier
                        than ever. Learn best practices for applications, how to spruce up your CV and how your skill
                        set maps to those in the industry. Watch our tutorial videos at your own pace.</p>
                </div>
            </div>
            <div class="card">
                <img src="images/icon/job-interview.png" class="card-img-top" alt="Interview Preparation">
                <div class="card-body">
                    <h5 class="card-title">Interview Preparation</h5>
                    <p class="card-text">Do remember to carefully go through the company profile and job listing before
                        the interview, and take a few minutes to watch some of our specially curated video tutorials.
                        Don’t worry, you’ve got this! Join a proud batch of thousands of ex-Navy personnel on the INPA
                        community as you put your best foot forward.</p>
                </div>
            </div>
        </div>

    </div>
</main>
<?php include("settings/include/footer.php"); ?>
<script>
     $(function() {
        var $clientslider = $('#clientlogo');
        var clients = $clientslider.children().length;
        var clientwidth = (clients * 220);
        $clientslider.css('width', clientwidth);
        var rotating = true;
        var clientspeed = 1800;
        var seeclients = setInterval(rotateClients, clientspeed);
        $(document).on({
            mouseenter: function() {
                rotating = false;
            },
            mouseleave: function() {
                rotating = true;
            }
        }, '#ourclients');

        function rotateClients() {
            if (rotating != false) {
                var $first = $('#clientlogo li:first');
                $first.animate({
                    'margin-left': '-220px'
                }, 2000, function() {
                    $first.remove().css({
                        'margin-left': '0px'
                    });
                    $('#clientlogo li:last').after($first);
                });
            }
        }
    });
</script>