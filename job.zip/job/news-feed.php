<?php
    include("settings/conn.php");
    $job = $conn->prepare("SELECT * FROM `jobs` WHERE `status` = 1");
    $job->execute();
    $job = $job->fetchAll(PDO::FETCH_ASSOC);
    $countLiveJobs = count($job);

    $company = $conn->prepare("SELECT * FROM `company`");
    $company->execute();
    $company = $company->fetchAll(PDO::FETCH_ASSOC);
    $countCompany = count($company);

    $user = $conn->prepare("SELECT * FROM `users`");
    $user->execute();
    $user = $user->fetchAll(PDO::FETCH_ASSOC);
    $countUser = count($user);
    include("settings/include/navbar.php");
?>
<main style="margin-top:110px">
    <h1 style="text-align:center">News Feed</h1>
    <?php
        include("settings/include/notification.php");
        include("status.php");
    ?>
</main>
<?php
    include("settings/include/footer.php");
?>