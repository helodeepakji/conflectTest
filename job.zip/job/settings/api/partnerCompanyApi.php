<?php

    include("../conn.php");
    session_start();
    $user_id = $_SESSION['userId'];

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'addPartner')) {
        if($_POST['url'] != '' && $_FILES['image']['name'] != ''){
            $url = $_POST['url'];

            $image = basename($_FILES['image']['name']);
            $uploadPath = '../../images/partners/' . $image;
            move_uploaded_file($_FILES['image']['tmp_name'], $uploadPath);

            $stmt = $conn->prepare("INSERT INTO `partners` (`url`, `image`) VALUES (?, ?)");
            $result = $stmt->execute([$url, 'images/partners/'.$image]);
            if($result){
                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Added successfully']);
            }else{
                http_response_code(500);
                echo json_encode(['success' => true, 'message' => 'Something Went Worng']);
            }

        }else{
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Fill All Required Fields']);
        }
    }

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'deletePartner')) {
            $stmt = $conn->prepare("DELETE FROM `partners` WHERE `id` = ?");
            $result = $stmt->execute([$_POST['id']]);
            if($result){
                http_response_code(200);
                echo json_encode(['success' => true, 'message' => 'Delete successfully']);
            }else{
                http_response_code(500);
                echo json_encode(['success' => true, 'message' => 'Something Went Worng']);
            }
    }