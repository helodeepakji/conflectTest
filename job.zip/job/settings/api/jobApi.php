<?php

    include("../conn.php");
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'addJob')) {
        if($_POST['job_title'] != '' && $_POST['location'] != '' && $_POST['Company_id'] != '' && $_POST['job_type'] != '' && $_POST['description'] != '' && $_POST['reference'] != ''){

            if($_POST['Company_id'] == 'other'){
                try {
                    $conn->beginTransaction();
                    if($_POST['company_name'] != '' && $_POST['company_details'] != '' && $_FILES['company_logo']['name']){
    
                        $company_logo = basename($_FILES['company_logo']['name']);
                        $uploadPath = '../../upload/' . $company_logo;
                        move_uploaded_file($_FILES['company_logo']['tmp_name'], $uploadPath);
                        $company_logo_link = $socket . 'upload/' . $company_logo;
    
                        $company = $conn->prepare('INSERT INTO `company`( `company`, `image`, `description`) VALUES ( ? , ? , ? )');
                        $result0 = $company->execute([$_POST['company_name'], $company_logo_link , $_POST['company_details']]);
                        if($result0){
                            $lastInsertId = $conn->lastInsertId();
                            $jobArray = [$_POST['job_title'] , $lastInsertId , $_POST['description'], $_POST['reference'], $_POST['job_type'], $_POST['location']];
                            $job = $conn->prepare('INSERT INTO `jobs`(`title`, `company_id`, `description`, `reference`, `job_type`, `location`) VALUES (? , ? , ? , ?,  ? , ?)');
                            $result =  $job->execute($jobArray);
                            if($result){
                                $conn->commit();
                                http_response_code(200);
                                echo json_encode(["message" => "Job Uploaded Successfull." , "status" => 200]);
                            }else{
                                $conn->rollBack();
                                http_response_code(500);
                                echo json_encode(["message" => "Something went wrong" , "status" => 500]);
                            }
                        }
                    }
                } catch (PDOException $e) {
                    $conn->rollBack();
                    http_response_code(500);
                    echo json_encode(["message" => "Database error: " . $e->getMessage(), "status" => 500]);
                }
            }else{
                $jobArray = [$_POST['job_title'] , $_POST['Company_id'], $_POST['description'], $_POST['reference'], $_POST['job_type'], $_POST['location'], $_POST['salary']];
                $job = $conn->prepare('INSERT INTO `jobs`(`title`, `company_id`, `description`, `reference`, `job_type`, `location` , `salary`) VALUES (? , ? , ? , ?,  ? , ?, ?)');
                $result =  $job->execute($jobArray);
                if($result){
                    http_response_code(200);
                    echo json_encode(["message" => "Job Uploaded Successfull." , "status" => 200]);
                }else{
                    http_response_code(500);
                    echo json_encode(["message" => "Something went wrong" , "status" => 500]);
                }
            }

        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'updateJob')) {
        if($_POST['job_title'] != '' && $_POST['location'] != '' && $_POST['job_id'] != '' && $_POST['job_type'] != '' && $_POST['description'] != '' && $_POST['reference'] != '' && $_POST['status'] != ''){

            $jobArray = [$_POST['job_title'] , $_POST['Company_id'], $_POST['description'], $_POST['reference'], $_POST['job_type'], $_POST['location'],  $_POST['status'], $_POST['salary'], $_POST['job_id']];
            $job = $conn->prepare('UPDATE `jobs` SET `title` = ? , `company_id` = ?, `description` = ?, `reference` = ?, `job_type` = ?, `location` = ? , `status` = ? , `salary` = ? WHERE `id` = ?');
            $result =  $job->execute($jobArray);
            if($result){
                http_response_code(200);
                echo json_encode(["message" => "Job Uploaded Successfull." , "status" => 200]);
            }else{
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong" , "status" => 500]);
            }

        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'deleteJob')) {
        if($_POST['job_id'] != ''){

            $job = $conn->prepare('DELETE FROM `jobs` WHERE `id` = ?');
            $result =  $job->execute([$_POST['job_id']]);
            if($result){
                http_response_code(200);
                echo json_encode(["message" => "Job Delete Successfull." , "status" => 200]);
            }else{
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong" , "status" => 500]);
            }

        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }

    

?>