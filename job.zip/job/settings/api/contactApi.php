<?php

    include("../conn.php");

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'addContact')) {
        if($_POST['first_name'] != '' && $_POST['last_name'] != '' && $_POST['email'] != '' && $_POST['phone'] != '' && $_POST['message'] != ''){
    
            $contactS = $conn->prepare('INSERT INTO `contact`(`first_name`, `last_name`, `email` , `phone`, `message`) VALUES (? , ? , ? , ? , ? )');
            $result = $contactS->execute([$_POST['first_name'] , $_POST['last_name'] , $_POST['email'], $_POST['phone'] , $_POST['message']]);
            if($result){
                http_response_code(200);
                echo json_encode(["message" => "Contact Shortly" , "status" => 500]);
            }else{
                http_response_code(500);
                echo json_encode(["message" => "Something went wrong" , "status" => 500]);
            }

        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }
?>