<?php

include("../conn.php");

if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'forgetPassword')) {
    if($_POST['email'] != ''){

        $users = $conn->prepare('SELECT * FROM `users` WHERE `email` = ?');
        $users->execute([$_POST['email']]);
        $users = $users->fetch(PDO::FETCH_ASSOC);
        if($users){
            $name = $users['first_name'].' '.$users['last_name'];
            $otp = rand(111111,999999);
            $forget_password = $conn->prepare('INSERT INTO `forget_password`( `email`, `otp` ) VALUES ( ? , ?)');
            $forget_password->execute([$users['email'] , $otp]);

            http_response_code(200);
            echo json_encode(["message"=> "OTP Sent your mail.","status"=> 200,"email" => $_POST['email']]);
            $email_user = $_POST['email'];
            $modive = 'OTP INPA Forget Password.';
            $html = "<h3>Dear $name <br> OTP : $otp <br> <h2> Thank You </h2>";
            include "../smtp/mailfy.php";
            exit();
        }else{
            http_response_code(400);
            echo json_encode(["message"=> "User not found Register now.","status"=> 400]);
        }
    }else{
        http_response_code(400);
        echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
    }
}


if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'verifyOtp')) {
    if($_POST['email'] != '' && $_POST['otp'] != ''){
        $forget_password = $conn->prepare('SELECT * FROM `forget_password` WHERE `email` = ? AND `otp` = ?');
        $forget_password->execute([$_POST['email'], $_POST['otp']]);
        $forget_password = $forget_password->fetch(PDO::FETCH_ASSOC);
        if($forget_password){
            $givenDateTime = strtotime($forget_password['created_at']);
            $currentTimestamp = time();
            $minutesDifference = ($currentTimestamp - $givenDateTime) / 60;
            if ($minutesDifference <= 5) {
                http_response_code(200);
                echo json_encode(["message"=> "Successfull Verified","status"=> 400,"email" => $_POST['email'] , "otp" => $_POST['otp']]);
            } else {
                http_response_code(400);
                echo json_encode(["message"=> "OTP is expired","status"=> 400,"email" => $_POST['email']]);
            }
            exit();
        }else{
            http_response_code(400);
            echo json_encode(["message"=> "OTP is not matched.","status"=> 400]);
        }
    }else{
        http_response_code(400);
        echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
    }
}


if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'setPassword')) {
    if($_POST['email'] != '' && $_POST['otp'] != '' && $_POST['cpassword'] != '' && $_POST['password'] != ''){
        $forget_password = $conn->prepare('SELECT * FROM `forget_password` WHERE `email` = ? AND `otp` = ?');
        $forget_password->execute([$_POST['email'], $_POST['otp']]);
        $forget_password = $forget_password->fetch(PDO::FETCH_ASSOC);
        if($forget_password){
            $givenDateTime = strtotime($forget_password['created_at']);
            $currentTimestamp = time();
            $minutesDifference = ($currentTimestamp - $givenDateTime) / 60;
            if ($minutesDifference <= 5) {
                if($_POST['password'] == $_POST['cpassword']){
                    $hashpassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
                    $user = $conn->prepare('UPDATE `users` SET `password` = ? WHERE `email` = ?');
                    $result = $user->execute([$hashpassword, $_POST['email']]);
                    if($result){
                        http_response_code(200);
                        echo json_encode(["message"=> "Successfull Password Changed.","status"=> 400,"email" => $_POST['email']]);
                    }else{  
                        http_response_code(500);
                        echo json_encode(["message"=> "Something Went Wrong","status"=> 400,"email" => $_POST['email']]); 
                    }
                }else{
                    http_response_code(400);
                    echo json_encode(["message"=> "Password & Confirm Password is not matched","status"=> 400,"email" => $_POST['email']]);
                }
            } else {
                http_response_code(400);
                echo json_encode(["message"=> "OTP is expired","status"=> 400,"email" => $_POST['email']]);
            }
            exit();
        }else{
            http_response_code(400);
            echo json_encode(["message"=> "OTP is not matched.","status"=> 400]);
        }
    }else{
        http_response_code(400);
        echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
    }
}




?>