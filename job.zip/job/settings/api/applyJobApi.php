<?php

    include("../conn.php");
    session_start();
    $user_id = $_SESSION['userId'];

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'applyJob')) {
        if($_POST['job_id'] != '' && $_POST['company_id'] != '' && $_POST['qualification'] != '' && $_POST['rank'] != ''){

            $check = $conn->prepare('SELECT * FROM `applied_jobs` WHERE `user_id` = ? AND `job_id` = ?');
            $check->execute([$user_id , $_POST['job_id']]);
            $check = $check->fetch(PDO::FETCH_ASSOC);
            if(!$check){
                if($_FILES['cv']['name'] != ''){
                    $cv = basename($_FILES['cv']['name']);
                    $uploadPath = '../../upload/' . $cv;
                    move_uploaded_file($_FILES['cv']['tmp_name'], $uploadPath);
                    $cvfile = $socket . 'upload/' . $cv;
                    $user = $conn->prepare('UPDATE `users` SET `cv` = ? WHERE `id` = ?');
                    $user->execute([$cvfile,$user_id]);
                }
    
                $applyJob = $conn->prepare('INSERT INTO `applied_jobs`(`user_id`, `job_id`, `company_id`) VALUES (? , ? , ? )');
                $result = $applyJob->execute([$user_id , $_POST['job_id'] ,$_POST['company_id'] ]);
                if($result){
                    http_response_code(200);
                    echo json_encode(["message" => "Successfull Applied" , "status" => 200]);

                    $job = $conn->prepare("SELECT * FROM `jobs` WHERE `id` = ? AND `status` = 1");
                    $job->execute([$_POST['job_id']]);
                    $job = $job->fetch(PDO::FETCH_ASSOC);

                    $company = $conn->prepare("SELECT * FROM `company` WHERE `id` = ? ");
                    $company->execute([$job["company_id"]]);
                    $company = $company->fetch(PDO::FETCH_ASSOC);
                    
                    $user = $conn->prepare("SELECT * FROM `users` WHERE `id` = ? ");
                    $user->execute([$user_id]);
                    $user = $user->fetch(PDO::FETCH_ASSOC);

                    $rank  = $user['rank'];
                    $qualification = $user['qualification'];

                    $name = $_POST['first_name'].' '.$_POST['last_name'];
                    $phone = $_POST['phone'];
                    $email_user = $_POST['email'];
                    $messag = $job['title'].' ('.$company['company'].') '.' <a href="'.$user['cv'].'">CV/Resume Click here</a>';
                    $modive = 'Apply Job for '.$job['title'].' ('.$company['company'].')';
                    $html = "<h3>Dear $name <br> Phone : $phone <br> Email : $email_user <br> Rank : $rank <br> Qualification : $qualification <br> Position : $messag </h3> <br> <h2> Thank You For Apply this Job </h2>";
                    include "../smtp/mailfy.php";

                }else{
                    http_response_code(500);
                    echo json_encode(["message" => "Something went wrong" , "status" => 500]);
                }
            }else{
                http_response_code(400);
                echo json_encode(["message"=> "You already applied this job.","status"=> 400]); 
            }

        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }
?>