<?php

    include("../conn.php");
    session_start();
    $user_id = $_SESSION["userId"];
    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'updatedata')) {

        if(isset($_FILES['profile']['name']) && $_FILES['profile']['name'] != ''){
            $profile = basename($_FILES['profile']['name']);
            $uploadPath = '../../upload/' . $profile;
            move_uploaded_file($_FILES['profile']['tmp_name'], $uploadPath);
            $profile_link = $socket . 'upload/' . $profile;

            $updateProfile = $conn->prepare('UPDATE `users` SET `profile` = ? WHERE `id` = ?');
            $result = $updateProfile->execute([ $profile_link ,$user_id]);
        }
        
        if(isset($_FILES['cv']['name']) && $_FILES['cv']['name'] != ''){
            $cvfiles = basename($_FILES['cv']['name']);
            $uploadPath = '../../upload/' . $cvfiles;
            move_uploaded_file($_FILES['cv']['tmp_name'], $uploadPath);
            $cvfiles_link = $socket . 'upload/' . $cvfiles;

            $updateProfile = $conn->prepare('UPDATE `users` SET `cv` = ? WHERE `id` = ?');
            $result = $updateProfile->execute([ $cvfiles_link ,$user_id]);
        }


        if($_POST['first_name'] != '' && $_POST['last_name'] != '' && $_POST['email'] != '' && $_POST['phone'] != '' && $_POST['rank'] != '' && $_POST['qualification'] != ''){

            $updateProfile = $conn->prepare('UPDATE `users` SET `first_name` = ? , `last_name` = ? , `email` = ? , `phone` = ? , `rank` = ? , `qualification` = ?  WHERE `id` = ?');
            $result = $updateProfile->execute([ $_POST['first_name'] , $_POST['last_name'] , $_POST['email'] , $_POST['phone'] , $_POST['rank'] ,$_POST['qualification'] ,$user_id]);

        }

       
        if($result){
            http_response_code(200);
            echo json_encode(["message" => "Uploaded Successfull." , "status" => 200]);
        }else{
            http_response_code(400);
            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
        }
    }

    if (($_SERVER["REQUEST_METHOD"] == "POST") && ($_POST['type'] == 'changePassword')) {

        if($_POST['old_password'] != '' && $_POST['new_password'] != '' && $_POST['confirm_password'] != ''){

            $check = $conn->prepare('SELECT * FROM `users` WHERE `id` = ?');
            $check->execute([$user_id]);
            $result = $check->fetch();
            if($result){

                if (password_verify($_POST['old_password'], $result['password'])) {
                    if($_POST['new_password'] === $_POST['confirm_password']){
                        $hashpassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                        $updateProfile = $conn->prepare('UPDATE `users` SET `password` = ?  WHERE `id` = ?');
                        $result = $updateProfile->execute([ $hashpassword ,$user_id]);
                        if($result){
                            http_response_code(200);
                            echo json_encode(["message" => "Uploaded Successfull." , "status" => 200]);
                        }else{
                            http_response_code(400);
                            echo json_encode(["message"=> "FIll All Required Field.","status"=> 400]);
                        }
                    }else{
                        http_response_code(400);
                        echo json_encode(["message"=> "Password & Confirm is not matched.","status"=> 400]);
                    }
                }else{
                    http_response_code(400);
                    echo json_encode(["message"=> "Old Password is not match.","status"=> 400]);
                }
            }else{
                http_response_code(400);
                echo json_encode(["message"=> "User not found.","status"=> 400]);
            }


        }else{
            http_response_code(400);
            echo json_encode(["message"=> "Fill All Required Fields.","status"=> 200]);
        }
    }

?>