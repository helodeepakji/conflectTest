<?php
include('smtp/PHPMailerAutoload.php');

$email = "helodeepakji@gmail.com";
echo smtp_mailer($email,$modive,$html);
function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	// $mail->SMTPDebug  = 3;
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = "kushwahadeepak783@gmail.com";
	$mail->Password = "futuibsrgwcqbdme";
	$mail->SetFrom('kushwahadeepak783@gmail.com','NXTTOUR INDIA');
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddBCC($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));
	if(!$mail->Send()){
		echo $mail->ErrorInfo;
	}else{
		// $return = "success";
		// return $return;
	}
}
?>