<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {

} else {
    $user_id = $_SESSION['userId'];
    $user = $conn->prepare("SELECT * FROM `users` WHERE `id` = ?");
    $user->execute([$user_id]);
    $user = $user->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.0.1/css/bootstrap-grid.min.css"
        integrity="sha512-Aa+z1qgIG+Hv4H2W3EMl3btnnwTQRA47ZiSecYSkWavHUkBF2aPOIIvlvjLCsjapW1IfsGrEO3FU693ReouVTA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf@3/notyf.min.css">
    <link rel="stylesheet" href="settings/include/notiflix.css">


    <style>
        .dropdown-toggle::after {
            display: none;
        }

        .text-decoration-none {
            text-decoration: none !important;
        }

        .icon-width {
            width: 2rem;
        }

        .btn-primary {
            color: #fff;
            background-color: #04127b;
            border-color: #04127b;
        }

        .profile img {
            border-radius: 50%;
        }

        .profile {
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light shadow-sm bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Indian_Navy_Crest.png" width="50px"
                    alt="">
                <span class="ml-3 font-weight-bold">INPA</apan>
            </a>
            <button class="navbar-toggler navbar-toggler-right border-0" type="button" data-toggle="collapse"
                data-target="#navbar4">
                <span class="navbar-toggler-icon"></span>
            </button>


            <div class="collapse navbar-collapse" id="navbar4">
                <ul class="navbar-nav mr-auto pl-lg-4">
                    <li class="nav-item px-lg-2 active"> <a class="nav-link" href="index.php"> <span
                                class="d-inline-block d-lg-none icon-width"><i class="fas fa-home"></i></span>Home</a>
                    </li>
                    <li class="nav-item px-lg-2"> <a class="nav-link" href="about.php"><span
                                class="d-inline-block d-lg-none icon-width"><i
                                    class="far fa-user"></i></i></span>About</a> </li>
                    <li class="nav-item px-lg-2"> <a class="nav-link" href="contact.php"><span
                                class="d-inline-block d-lg-none icon-width"><i
                                    class="far fa-envelope"></i></span>Contact</a> </li>
                    <li class="nav-item px-lg-2"> <a class="nav-link" href="news-feed.php"><span
                                class="d-inline-block d-lg-none icon-width"><i
                                    class="far fa-envelope"></i></span>News Feed</a> </li>
                    <?php
                    // if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                    //     echo '<li class="nav-item px-lg-2 dropdown d-menu">
                    //     <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown"
                    //         aria-haspopup="true" aria-expanded="false"><span
                    //             class="d-inline-block d-lg-none icon-width"><i
                    //                 class="far fa-caret-square-down"></i></span>Settings
                    //         <svg id="arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                    //             viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                    //             stroke-linecap="round" stroke-linejoin="round">
                    //             <polyline points="6 9 12 15 18 9"></polyline>
                    //         </svg>
                    //     </a>
                    //     <div class="dropdown-menu shadow-sm sm-menu" aria-labelledby="dropdown01">
                    //         <a class="dropdown-item" href="profile.php">Profile</a>
                    //         <a class="dropdown-item" href="applied-job.php">Applied Job</a>
                    //         <a class="dropdown-item" href="logout.php">Log Out</a>
                    //     </div>
                    // </li>';
                    // } else {
                    //     echo '<li class="nav-item px-lg-2"> <a class="nav-link" href="login.php"><span
                    //     class="d-inline-block d-lg-none icon-width"><i
                    //         class="far fa-envelope"></i></span>Login</a> </li>';
                    // }
                    ?>



                </ul>
                <ul class="navbar-nav ml-auto mt-3 mt-lg-0">
                    <?php
                    if (isset($_SESSION['userType']) && $_SESSION['userType'] == 'admin') {
                        if (isset($uploadJob) && $uploadJob == true) {
                            ?>
                            <button class="btn btn-primary mt-2" data-bs-toggle="modal" href="#upload_job_form" style="margin:0 10px"><i
                                    class="fa-solid fa-cloud-arrow-up" style="margin: 0 10px;"></i> Upload Job</button>
                        <?php } ?>
                            <a href="admin/applied-jobs.php" class="btn btn-primary mt-2" style="margin:0 10px"> Admin</a>
                        <?php
                    }
                    ?>
                </ul>
                <?php
                    if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                        echo '<a href="profile.php"><div class="profile dropdown d-menu">
                                <img src="'.($user['profile'] == '' ? 'upload/avatar-1-2.jpg' : $user['profile']).'" width="50px" height="50px" alt="">
                                <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false"><span
                                        class="d-inline-block d-lg-none icon-width"><i
                                            class="far fa-caret-square-down"></i></span>'.$user['first_name'].' '.$user['last_name'].'
                                    <svg id="arrow" xmlns="http://www.w3.org/2000/svg" width="14" height="14"
                                        viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                        stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="6 9 12 15 18 9"></polyline>
                                    </svg>
                                </a>
                                <div class="dropdown-menu shadow-sm sm-menu" aria-labelledby="dropdown01">
                                    <a class="dropdown-item" href="profile.php">Profile</a>
                                    <a class="dropdown-item" href="applied-job.php">Applied Job</a>
                                    <a class="dropdown-item" href="logout.php">Log Out</a>
                                </div>
                            </div></a>';
                    }else{
                        echo '<a href="login.php" class="btn btn-primary mt-2" style="margin:0 10px"> Login</a>';
                    }
                ?>
            </div>
        </div>
    </nav>