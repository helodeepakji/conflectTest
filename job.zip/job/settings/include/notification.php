<style>
    .leftsideNotifications_New {
        position: relative;
    }

    .leftsideNotifications_New {
        background: #fff;
        padding: 5px 5px;
        border-radius: 5px;
        margin: 8px 0px;
    }

    .leftsideNotifications_New {
        margin-bottom: 20px;
        border: 1px solid #ddd;
    }

    .leftsideNotifications_New h3 {
        font: 500 20px 'Roboto', sans-serif;
        color: #fff;
        text-transform: capitalize;
        padding: 8px 12px;
        background: rgb(143 143 143);
        border-bottom: 1px solid #ddd;
        margin: 0px 0px;
        font-weight: bold;
    }

    .leftsideNotifications_New ul {
        padding: 0px 10px;
    }

    .leftsideNotifications_New ul li {
        line-height: 25px;
        height: 70px;
    }

    li{
        list-style: none;
    }

    .leftsideNotifications_New ul li {
        border-bottom: 1px solid #ddd;
        padding: 5px 0px 5px;
    }

    .eachNotification span {
        color: darkblue;
        font-size: 11px;
        padding-right: 9px;
        float: left;
        width: 8%;
        text-align: center;
    }

    .leftsideNotifications_New ul li p {
        margin-bottom: 0px;
    }

    .eachNotification p {
        vertical-align: top;
        width: 92%;
        padding-top: 20px;
        line-height: 22px;
    }

    .eachNotification span i {
        font-weight: 600;
        font-style: normal;
        font-size: 17px;
        display: block;
        margin-top: -8px;
        margin-bottom: -8px;
    }

    .eachNotification p a {
        color: #222;
        font: 500 14px 'Roboto', sans-serif;
    }

    a {
        cursor: pointer;
        outline: none;
        text-decoration: none;
        transition: all .5s ease;
    }

    img.file-icon {
        width: auto !important;
        padding: 3px;
    }
</style>
<div class="container" id="LatestNewsSec">


    <div class="leftsideNotifications_New">
        <h3>Latest News</h3>
        <div class="scrollingNotifications_New scrollbar" id="forScrollNews">
            <ul>
                <?php 
                    $notifications = $conn->query("SELECT * FROM `notification` ORDER BY `created_at` DESC LIMIT 10");
                    $notifications->execute();
                    $notifications = $notifications->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($notifications as $nofication) {
                       echo '
                        <li>
        
                            <div class="eachNotification ">
                                <span>'.date("M", strtotime($nofication['created_at'])).'<i>'.date("d", strtotime($nofication['created_at'])).'</i>'.date("Y", strtotime($nofication['created_at'])).'</span>
                                <p class="English">
                                    <img src="https://ssc.nic.in/Content/library/assets/images/new.gif" alt="new gif Image">
                                    <a href="'.$nofication['file'].'"
                                        target="_blank">
                                        '.$nofication['notification'].'
                                    </a>
                                    <img class="file-icon" alt="" title="pdf document. opens in new tab"
                                        src="/Content/library/assets/images/icons/pdficon.png">
                                </p>
                            </div>
                        </li>
                       ';
                    }
                ?>
            </ul>
        </div>
    </div>
</div>